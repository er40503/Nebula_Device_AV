#ifndef PARSE_H_
#define PARSE_H_

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#include "sample_sys.h"

/*Note if the order of enum change, please also modify case configuration file */
enum sample_case_enum {
	SAMPLE_CASE_NONE = 0,
	SAMPLE_CASE_NORMAL_STREAM = 1,
	SAMPLE_CASE_180_VIDEO = 2,
	//	SAMPLE_CASE_SPHERE_VIDEO          = 2,
	//	SAMPLE_CASE_FISHEYE_3_SPLIT       = 3,
	//	SAMPLE_CASE_NORMAL_STREAM_WITH_MV = 4,
	//	SAMPLE_CASE_180_VIDEO_WITH_MV     = 6,
	//	SAMPLE_CASE_NORMAL_STREAM_WITH_MVINK = 7,
	SAMPLE_CASE_END,
};

void init_conf(SAMPLE_CONF_S *conf);
int parse(int argc, char *argv[], SAMPLE_CONF_S *conf);
void show_result(SAMPLE_CONF_S *conf);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* !PARSE_H_ */
