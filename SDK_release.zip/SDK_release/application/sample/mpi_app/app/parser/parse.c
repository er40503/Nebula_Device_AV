#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>

#include <parse.h>
#include <mpi_common.h>
#include <mpi_sys.h>
#include <mpi_osd.h>
#include <mpi_iva.h>

#define VB_POOL_NUM MPI_MAX_PUB_POOL
#define DEV_NUM MPI_MAX_VIDEO_DEV_NUM
#define PATH_NUM MPI_MAX_INPUT_PATH_NUM
#define CHN_NUM MPI_MAX_VIDEO_CHN_NUM
#define WINDOW_NUM MPI_MAX_VIDEO_WIN_NUM
#define ENC_CHN_NUM MPI_MAX_ENC_CHN_NUM

#define INVALID_VB_POOL_IDX (-1)
#define MIN_VB_POOL_IDX (0)
#define MAX_VB_POOL_IDX (VB_POOL_NUM - 1)
#define INVALID_DEV_IDX (-1)
#define MIN_DEV_IDX (0)
#define MAX_DEV_IDX (DEV_NUM - 1)
#define INVALID_PATH_IDX (-1)
#define MIN_PATH_IDX (0)
#define MAX_PATH_IDX (PATH_NUM - 1)
#define INVALID_CHN_IDX (-1)
#define MIN_CHN_IDX (0)
#define MAX_CHN_IDX (CHN_NUM - 1)
#define INVALID_WINDOW_IDX (-1)
#define MIN_WINDOW_IDX (0)
#define MAX_WINDOW_IDX (WINDOW_NUM - 1)
#define INVALID_ENC_CHN_IDX (-1)
#define MIN_ENC_CHN_IDX (0)
#define MAX_ENC_CHN_IDX (ENC_CHN_NUM - 1)

#define INVALID_ENC_TYPE (-1)

typedef enum {
	TYPE_BOOL,
	TYPE_CHAR,
	TYPE_INT8,
	TYPE_UINT8,
	TYPE_INT16,
	TYPE_UINT16,
	TYPE_INT32,
	TYPE_UINT32,
	TYPE_FLOAT,
	TYPE_STR,
	TYPE_NUM,
} types;

/* Internal function prototype */
void help(char *str);

static void parse_str_to_upper(char *str)
{
	while ((*str = toupper(*str)))
		str++;
}

static void get_value(void *dest, types type)
{
	char *val = strtok(NULL, " =");

	//printf("val = |%s|.\n", val);

	switch (type) {
	case TYPE_BOOL:
		//  *(bool *)dest = (bool)atoi(val);
		break;

	case TYPE_INT8:
		*(INT8 *)dest = (INT8)atoi(val);
		break;

	case TYPE_UINT8:
		*(UINT8 *)dest = (UINT8)atoi(val);
		break;

	case TYPE_INT16:
		*(INT16 *)dest = (INT16)atoi(val);
		break;

	case TYPE_UINT16:
		*(UINT16 *)dest = (UINT16)atoi(val);
		break;

	case TYPE_INT32:
		*(INT32 *)dest = (INT32)atoi(val);
		break;

	case TYPE_UINT32:
		*(UINT32 *)dest = (UINT32)atoi(val);
		break;

	case TYPE_FLOAT:
		*(FLOAT *)dest = (FLOAT)atof(val);
		break;

	case TYPE_STR:
		//  *(char *)dest = (char *)atoi(val);
		break;

	default:
		break;
	}

	return;
}

static void get_res(MPI_SIZE_S *dest)
{
	char *val = strtok(NULL, " =");
	char *tok = NULL;

	//	printf("val = |%s|.\n", val);

	tok = strtok(val, " x");
	dest->width = (INT16)atoi(tok);

	val = strtok(NULL, " x");
	dest->height = (INT16)atoi(val);

	return;
}

/* Enum */
/*static void get_op_mode(MPI_OP_MODE_E *dest)
{
	char *val = strtok(NULL, " =\n");

//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "NORMAL")) {
		*dest = MPI_OP_MODE_NORMAL;
	} else if (!strcmp(val, "HDR")) {
		*dest = MPI_OP_MODE_HDR_FRAME_PARL;
	} else if (!strcmp(val, "STITCH")) {
		*dest = MPI_OP_MODE_STITCH;
	} else if (!strcmp(val, "EIS")) {
		*dest = MPI_OP_MODE_EIS;
	} else {
		printf("ERROR: Invalid operation mode (%s)\n", val);
	}

	return;
}*/

static void get_hdr_mode(MPI_HDR_MODE_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "NONE")) {
		*dest = MPI_HDR_MODE_NONE;
	} else if (!strcmp(val, "FRAME_PARL")) {
		*dest = MPI_HDR_MODE_FRAME_PARL;
	} else if (!strcmp(val, "FRAME_ITLV")) {
		*dest = MPI_HDR_MODE_FRAME_ITLV;
	} else if (!strcmp(val, "TOP_N_BTM")) {
		*dest = MPI_HDR_MODE_TOP_N_BTM;
	} else if (!strcmp(val, "SIDE_BY_SIDE")) {
		*dest = MPI_HDR_MODE_SIDE_BY_SIDE;
	} else if (!strcmp(val, "LINE_COLOC")) {
		*dest = MPI_HDR_MODE_LINE_COLOC;
	} else if (!strcmp(val, "LINE_ITLV")) {
		*dest = MPI_HDR_MODE_LINE_ITLV;
	} else if (!strcmp(val, "PIX_COLOC")) {
		*dest = MPI_HDR_MODE_PIX_COLOC;
	} else if (!strcmp(val, "PIX_ITLV")) {
		*dest = MPI_HDR_MODE_PIX_ITLV;
	} else {
		printf("ERROR: Invalid HDR mode (%s)\n", val);
	}

	return;
}

static void get_venc_type(MPI_VENC_TYPE_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "H264")) {
		*dest = MPI_VENC_TYPE_H264;
	} else if (!strcmp(val, "H265")) {
		*dest = MPI_VENC_TYPE_H265;
	} else if (!strcmp(val, "MJPEG")) {
		*dest = MPI_VENC_TYPE_MJPEG;
	} else if (!strcmp(val, "JPEG")) {
		*dest = MPI_VENC_TYPE_JPEG;
	} else {
		printf("ERROR: Invalid VENC type (%s)\n", val);
	}

	return;
}

static void get_enc_profile(MPI_VENC_PRFL_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "BASELINE")) {
		*dest = MPI_PRFL_BASELINE;
	} else if (!strcmp(val, "MAIN")) {
		*dest = MPI_PRFL_MAIN;
	} else if (!strcmp(val, "HIGH")) {
		*dest = MPI_PRFL_HIGH;
	} else {
		printf("ERROR: Invalid profile type (%s)\n", val);
	}

	return;
}

static void get_enc_rc_mode(MPI_RC_MODE_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "VBR")) {
		*dest = MPI_RC_MODE_VBR;
	} else if (!strcmp(val, "CBR")) {
		*dest = MPI_RC_MODE_CBR;
	} else if (!strcmp(val, "SBR")) {
		*dest = MPI_RC_MODE_SBR;
	} else if (!strcmp(val, "CQP")) {
		*dest = MPI_RC_MODE_CQP;
	} else {
		printf("ERROR: Invalid RC mode (%s)\n", val);
	}

	return;
}

static void get_rotate_type(MPI_ROTATE_TYPE_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "ROTATE_0")) {
		*dest = MPI_ROTATE_0;
	} else if (!strcmp(val, "ROTATE_90")) {
		*dest = MPI_ROTATE_90;
	} else if (!strcmp(val, "ROTATE_180")) {
		*dest = MPI_ROTATE_180;
	} else if (!strcmp(val, "ROTATE_270")) {
		*dest = MPI_ROTATE_270;
	} else {
		printf("ERROR: Invalid rotate degree (%s)\n", val);
	}

	return;
}

static void get_bayer_phase(MPI_BAYER_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "PHASE_G0")) {
		*dest = MPI_BAYER_PHASE_G0;
	} else if (!strcmp(val, "PHASE_R")) {
		*dest = MPI_BAYER_PHASE_R;
	} else if (!strcmp(val, "PHASE_B")) {
		*dest = MPI_BAYER_PHASE_B;
	} else if (!strcmp(val, "PHASE_G1")) {
		*dest = MPI_BAYER_PHASE_G1;
	} else {
		printf("ERROR: Invalid bayer phase (%s)\n", val);
	}

	return;
}

#if 0 // Was used in parse_chn_ldc_attr()
static void get_ldc_type(MPI_LDC_VIEW_TYPE_E *dest)
{
	char *val = strtok(NULL, " =\n");

//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "CROP")) {
		*dest = MPI_OSD_OVERLAY_POLYGON;
	} else if (!strcmp(val, "ALL")) {
		*dest = MPI_OSD_OVERLAY_LINE;
	} else {
		printf("ERROR: Invalid precision (%s)\n", val);
	}

	return;
}
#endif

static void get_osd_type(MPI_OSD_OVERLAY_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "RECTANGLE")) {
		*dest = MPI_OSD_OVERLAY_POLYGON;
	} else if (!strcmp(val, "LINE")) {
		*dest = MPI_OSD_OVERLAY_LINE;
	} else if (!strcmp(val, "BITMAP")) {
		*dest = MPI_OSD_OVERLAY_BITMAP;
	} else if (!strcmp(val, "BITMAP_BYPASS")) {
		*dest = MPI_OSD_OVERLAY_BITMAP_BYPASS;
	} else {
		printf("ERROR: Invalid precision (%s)\n", val);
	}

	return;
}

static void get_osd_color(MPI_OSD_OVERLAY_E *dest)
{
	char *val = strtok(NULL, " =\n");

	//	printf("val = |%s|.\n", val);

	parse_str_to_upper(val);

	if (!strcmp(val, "RED")) {
		*dest = 0x8A6E;
	} else if (!strcmp(val, "YELLOW")) {
		*dest = 0x9F18;
	} else if (!strcmp(val, "YELLOW1")) {
		*dest = 0x993B;
	} else if (!strcmp(val, "GREEN")) {
		*dest = 0x9F21;
	} else if (!strcmp(val, "BLUE")) {
		*dest = 0x84E7;
	} else if (!strcmp(val, "BLUE1")) {
		*dest = 0x9F91;
	} else if (!strcmp(val, "PURPLE")) {
		*dest = 0x93AA;
	} else if (!strcmp(val, "PINK")) {
		*dest = 0x8DDE;
	} else {
		printf("ERROR: Invalid precision (%s)\n", val);
	}

	return;
}

static int parse_mcvc_vbr_param(char *tok, MPI_MCVC_VBR_PARAM_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "max_bit_rate")) {
		get_value((void *)&p->max_bit_rate, TYPE_UINT32);
	} else if (!strcmp(tok, "quality_level_index")) {
		get_value((void *)&p->quality_level_index, TYPE_UINT32);
	} else if (!strcmp(tok, "fluc_level")) {
		get_value((void *)&p->fluc_level, TYPE_UINT32);
	} else if (!strcmp(tok, "regression_speed")) {
		get_value((void *)&p->regression_speed, TYPE_UINT32);
	} else if (!strcmp(tok, "scene_smooth")) {
		get_value((void *)&p->scene_smooth, TYPE_UINT32);
	} else if (!strcmp(tok, "i_continue_weight")) {
		get_value((void *)&p->i_continue_weight, TYPE_UINT32);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_mcvc_cbr_param(char *tok, MPI_MCVC_CBR_PARAM_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "bit_rate")) {
		get_value((void *)&p->bit_rate, TYPE_UINT32);
	} else if (!strcmp(tok, "fluc_level")) {
		get_value((void *)&p->fluc_level, TYPE_UINT32);
	} else if (!strcmp(tok, "regression_speed")) {
		get_value((void *)&p->regression_speed, TYPE_UINT32);
	} else if (!strcmp(tok, "scene_smooth")) {
		get_value((void *)&p->scene_smooth, TYPE_UINT32);
	} else if (!strcmp(tok, "i_continue_weight")) {
		get_value((void *)&p->i_continue_weight, TYPE_UINT32);
	} else if (!strcmp(tok, "max_qp")) {
		get_value((void *)&p->max_qp, TYPE_UINT32);
	} else if (!strcmp(tok, "min_qp")) {
		get_value((void *)&p->min_qp, TYPE_UINT32);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_mcvc_cqp_param(char *tok, MPI_MCVC_CQP_PARAM_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "i_frame_qp")) {
		get_value((void *)&p->i_frame_qp, TYPE_UINT32);
	} else if (!strcmp(tok, "p_frame_qp")) {
		get_value((void *)&p->p_frame_qp, TYPE_UINT32);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_mcvc_param(char *tok, MPI_MCVC_RC_ATTR_S *p)
{
	int hit = 0;

	switch (p->mode) {
	case MPI_RC_MODE_VBR:
		hit = parse_mcvc_vbr_param(tok, &p->vbr);
		break;
	case MPI_RC_MODE_CBR:
		hit = parse_mcvc_cbr_param(tok, &p->cbr);
		break;
	case MPI_RC_MODE_CQP:
		hit = parse_mcvc_cqp_param(tok, &p->cqp);
		break;
	default:
		printf("Invalid rc mode %d.\n", p->mode);
		hit = 0;
		break;
	}
	return hit;
}

static int parse_vc_param(char *tok, MPI_VC_RC_ATTR_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "bit_rate")) {
		get_value((void *)&p->bit_rate, TYPE_UINT32);
	} else if (!strcmp(tok, "max_q_factor")) {
		get_value((void *)&p->max_q_factor, TYPE_UINT32);
	} else if (!strcmp(tok, "min_q_factor")) {
		get_value((void *)&p->min_q_factor, TYPE_UINT32);
	} else if (!strcmp(tok, "max_bit_rate")) {
		get_value((void *)&p->max_bit_rate, TYPE_UINT32);
	} else if (!strcmp(tok, "quality_level_index")) {
		get_value((void *)&p->quality_level_index, TYPE_UINT32);
	} else if (!strcmp(tok, "q_factor")) {
		get_value((void *)&p->q_factor, TYPE_UINT32);
	} else if (!strcmp(tok, "fluc_level")) {
		get_value((void *)&p->fluc_level, TYPE_UINT32);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_h264_attr(char *tok, MPI_VENC_ATTR_H264_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "venc_profile")) {
		get_enc_profile((void *)&p->profile);
	} else if (!strcmp(tok, "rc_mode")) {
		get_enc_rc_mode(&p->rc.mode);
	} else if (!strcmp(tok, "gop_size")) {
		get_value((void *)&p->rc.gop, TYPE_UINT32);
	} else if (!strcmp(tok, "enc_fps")) {
		get_value((void *)&p->rc.frm_rate_o, TYPE_INT32);
	} else if (p->rc.mode < MPI_RC_MODE_NUM) {
		hit = parse_mcvc_param(tok, &p->rc);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_h265_attr(char *tok, MPI_VENC_ATTR_H265_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "venc_profile")) {
		get_enc_profile((void *)&p->profile);
	} else if (!strcmp(tok, "rc_mode")) {
		get_enc_rc_mode(&p->rc.mode);
	} else if (!strcmp(tok, "gop_size")) {
		get_value((void *)&p->rc.gop, TYPE_UINT32);
	} else if (!strcmp(tok, "enc_fps")) {
		get_value((void *)&p->rc.frm_rate_o, TYPE_UINT32);
	} else if (p->rc.mode < MPI_RC_MODE_NUM) {
		hit = parse_mcvc_param(tok, &p->rc);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_mjpeg_attr(char *tok, MPI_VENC_ATTR_MJPEG_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "rc_mode")) {
		get_enc_rc_mode(&p->rc.mode);
	} else if (!strcmp(tok, "enc_fps")) {
		get_value((void *)&p->rc.frm_rate_o, TYPE_UINT32);
	} else if (p->rc.mode < MPI_RC_MODE_NUM) {
		hit = parse_vc_param(tok, &p->rc);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_jpeg_attr(char *tok, MPI_VENC_ATTR_JPEG_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "q_factor")) {
		get_value((void *)&p->q_factor, TYPE_UINT32);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_chn_attr(char *tok, MPI_ENC_CHN_ATTR_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "enc_res")) {
		get_res(&p->res);
	} else if (!strcmp(tok, "max_enc_res")) {
		get_res(&p->max_res);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_bind_info(char *tok, MPI_ENC_BIND_INFO_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "bind_dev_idx")) {
		get_value((void *)&p->idx.dev, TYPE_UINT8);
	} else if (!strcmp(tok, "bind_chn_idx")) {
		get_value((void *)&p->idx.chn, TYPE_UINT8);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_enc_venc_attr(char *tok, MPI_VENC_ATTR_S *p)
{
	static MPI_VENC_TYPE_E type = MPI_VENC_TYPE_NUM;

	int hit = 0;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "venc_type")) {
		get_venc_type((void *)&p->type);
		type = p->type;

		hit = 1;

		goto end;
	}

	if (type < MPI_VENC_TYPE_NUM) {
		switch (type) {
		case MPI_VENC_TYPE_H264:
			hit = parse_enc_h264_attr(tok, &p->h264);
			break;
		case MPI_VENC_TYPE_H265:
			hit = parse_enc_h265_attr(tok, &p->h265);
			break;
		case MPI_VENC_TYPE_MJPEG:
			hit = parse_enc_mjpeg_attr(tok, &p->mjpeg);
			break;
		case MPI_VENC_TYPE_JPEG:
			hit = parse_enc_jpeg_attr(tok, &p->jpeg);

			break;
		default:
			printf("Invalid encode type %d.\n", type);
			hit = 0;
			break;
		}
	} else {
		hit = 0;
	}
end:
	return hit;
}

static int parse_enc_venc_attr_ex(char *tok, MPI_VENC_ATTR_EX_S *p)
{
	int hit = 0;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "obs")) {
		get_value((void *)&p->obs, TYPE_UINT32);
		hit = 1;
	}

	return hit;
}

static int parse_osd_polygon_attr(char *tok, MPI_OSD_POLYGON_ATTR_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "osd_color")) {
		get_osd_color((void *)&p->color);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_osd_line_attr(char *tok, MPI_OSD_LINE_ATTR_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "osd_color")) {
		get_osd_color((void *)&p->color);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_path_gen_param(char *tok, MPI_PATH_ATTR_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "sensor_idx")) {
		get_value((void *)&p->sensor_idx, TYPE_INT32);
	} else if (!strcmp(tok, "input_res")) {
		get_res((void *)&p->res);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_chn_case_param(char *tok, CONF_CASE_CHN_PARAM *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "udpstream_enable")) {
		get_value((void *)&p->udpstream_enable, TYPE_UINT8);
	} else if (!strcmp(tok, "frame_num")) {
		get_value((void *)&p->frame_num, TYPE_INT32);
	} else if (!strcmp(tok, "record_enable")) {
		get_value((void *)&p->record_enable, TYPE_UINT8);
	} else if (!strcmp(tok, "client_ip")) {
		char *val = strtok(NULL, " =\n");
		strncpy(p->client_ip, val, MAX_IP_LENGTH);
	} else if (!strcmp(tok, "client_port")) {
		get_value((void *)&p->client_port, TYPE_UINT32);
	} else if (!strcmp(tok, "output_file")) {
		char *val = strtok(NULL, " =\n");
		strcpy(p->output_file, val);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_chn_gen_param(char *tok, MPI_CHN_ATTR_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "output_res")) {
		get_res(&p->res);
//	} else if (!strcmp(tok, "max_output_res")) {
//		get_res(&p->max_res);
	} else if (!strcmp(tok, "output_fps")) {
		get_value((void *)&p->fps, TYPE_FLOAT);
//	} else if (!strcmp(tok, "rotate")) {
//		get_rotate_type(&p->rotate);
//	} else if (!strcmp(tok, "mirror")) {
//		get_value((void *)&p->mirr_en, TYPE_UINT8);
//	} else if (!strcmp(tok, "flip")) {
//		get_value((void *)&p->flip_en, TYPE_UINT8);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_rect_param(char *tok, MPI_RECT_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "rect_x")) {
		get_value((void *)&p->x, TYPE_UINT16);
	} else if (!strcmp(tok, "rect_y")) {
		get_value((void *)&p->y, TYPE_UINT16);
	} else if (!strcmp(tok, "rect_width")) {
		get_value((void *)&p->width, TYPE_UINT16);
	} else if (!strcmp(tok, "rect_height")) {
		get_value((void *)&p->height, TYPE_UINT16);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_chn_layout_param(char *tok, MPI_CHN_LAYOUT_S *p)
{
	static int idx = 0;
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "window_num")) {
		get_value((void *)&p->window_num, TYPE_INT32);
	} else if (!strcmp(tok, "layout_window_idx")) {
		get_value((void *)&idx, TYPE_INT32);
	} else {
		hit = 0;
	}

	if (!hit) {
		hit = parse_rect_param(tok, &p->window[idx]);
	}

	return hit;
}

static int parse_win_attr(char *tok, MPI_WIN_ATTR_S *p)
{
	static INT32 w_idx = INVALID_WINDOW_IDX;

	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "window_idx")) {
		get_value((void *)&w_idx, TYPE_INT32);
		return hit;
	}

	if (w_idx >= MIN_WINDOW_IDX && w_idx <= MAX_WINDOW_IDX) {

		if (!strcmp(tok, "path_bmp")) {
			get_value((void *)&p[w_idx].path.bmp, TYPE_UINT32);
		} else if (!strcmp(tok, "window_fps")) {
			get_value((void *)&p[w_idx].fps, TYPE_FLOAT);
		} else if (!strcmp(tok, "rotate")) {
			get_rotate_type((void *)&p[w_idx].rotate);
		} else if (!strcmp(tok, "mirror")) {
			get_value((void *)&p[w_idx].mirr_en, TYPE_UINT8);
		} else if (!strcmp(tok, "flip")) {
			get_value((void *)&p[w_idx].flip_en, TYPE_UINT8);
		} else if (!strcmp(tok, "win_type")) {
			get_value((void *)&p[w_idx].view_type, TYPE_INT32);
		} else if (!strcmp(tok, "roi_x")) {
			get_value((void *)&p[w_idx].roi.x, TYPE_UINT16);
		} else if (!strcmp(tok, "roi_y")) {
			get_value((void *)&p[w_idx].roi.y, TYPE_UINT16);
		} else if (!strcmp(tok, "roi_width")) {
			get_value((void *)&p[w_idx].roi.width, TYPE_UINT16);
		} else if (!strcmp(tok, "roi_height")) {
			get_value((void *)&p[w_idx].roi.height, TYPE_UINT16);
		} else if (!strcmp(tok, "priority")) {
			get_value((void *)&p[w_idx].prio, TYPE_UINT8);
		} else if (!strcmp(tok, "parent")) {
			get_value((void *)&p[w_idx].src_id, TYPE_INT32);
		} else if (!strcmp(tok, "const_qual")) {
			get_value((void *)&p[w_idx].const_qual, TYPE_UINT8);
		} else if (!strcmp(tok, "dyn_adj")) {
			get_value((void *)&p[w_idx].dyn_adj, TYPE_UINT8);
		} else {
			hit = 0;
		}
	}

	return hit;
}

static int parse_chn_dist_param(char *tok, MPI_STITCH_DIST_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "dist")) {
		get_value((void *)&p->dist, TYPE_UINT16);
	} else if (!strcmp(tok, "ver_disp")) {
		get_value((void *)&p->ver_disp, TYPE_UINT16);
	} else if (!strcmp(tok, "straighten")) {
		get_value((void *)&p->straighten, TYPE_UINT16);
	} else if (!strcmp(tok, "src_zoom")) {
		get_value((void *)&p->src_zoom, TYPE_UINT16);
	} else if (!strcmp(tok, "theta_0")) {
		get_value((void *)&p->theta[0], TYPE_INT16);
	} else if (!strcmp(tok, "theta_1")) {
		get_value((void *)&p->theta[1], TYPE_INT16);
	} else if (!strcmp(tok, "radius_0")) {
		get_value((void *)&p->radius[0], TYPE_UINT16);
	} else if (!strcmp(tok, "radius_1")) {
		get_value((void *)&p->radius[1], TYPE_UINT16);
	} else if (!strcmp(tok, "curvature_0")) {
		get_value((void *)&p->curvature[0], TYPE_UINT16);
	} else if (!strcmp(tok, "curvature_1")) {
		get_value((void *)&p->curvature[1], TYPE_UINT16);
	} else if (!strcmp(tok, "fov_ratio_0")) {
		get_value((void *)&p->fov_ratio[0], TYPE_UINT16);
	} else if (!strcmp(tok, "fov_ratio_1")) {
		get_value((void *)&p->fov_ratio[1], TYPE_UINT16);
	} else if (!strcmp(tok, "ver_scale_0")) {
		get_value((void *)&p->ver_scale[0], TYPE_UINT16);
	} else if (!strcmp(tok, "ver_scale_1")) {
		get_value((void *)&p->ver_scale[1], TYPE_UINT16);
	} else if (!strcmp(tok, "ver_shift_0")) {
		get_value((void *)&p->ver_shift[0], TYPE_INT16);
	} else if (!strcmp(tok, "ver_shift_1")) {
		get_value((void *)&p->ver_shift[1], TYPE_INT16);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_chn_stitch_attr(char *tok, MPI_STITCH_ATTR_S *p)
{
	static int idx = 0;
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "stitch")) {
		get_value((void *)&p->enable, TYPE_UINT8);
	} else if (!strcmp(tok, "center_0_x")) {
		get_value((void *)&p->center[0].x, TYPE_UINT16);
	} else if (!strcmp(tok, "center_0_y")) {
		get_value((void *)&p->center[0].y, TYPE_UINT16);
	} else if (!strcmp(tok, "center_1_x")) {
		get_value((void *)&p->center[1].x, TYPE_UINT16);
	} else if (!strcmp(tok, "center_1_y")) {
		get_value((void *)&p->center[1].y, TYPE_UINT16);
	} else if (!strcmp(tok, "dft_dist")) {
		get_value((void *)&p->dft_dist, TYPE_INT32);
	} else if (!strcmp(tok, "dist_tbl_num")) {
		get_value((void *)&p->table_num, TYPE_INT32);
	} else if (!strcmp(tok, "dist_idx")) {
		get_value((void *)&idx, TYPE_INT32);
	} else {
		hit = 0;
	}

	if (!hit) {
		hit = parse_chn_dist_param(tok, &p->table[idx]);
	}

	return hit;
}

static int parse_chn_ldc_attr(char *tok, MPI_LDC_ATTR_S *p)
{
	//static int idx = 0;
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	//	if (!strcmp(tok, "ldc_type")) {
	//		get_ldc_type((void *)&p->ldc_info.view_type);
	//		hit = 1;
	//		goto end;
	//	}

	if (!strcmp(tok, "ldc_en")) {
		get_value((void *)&p->enable, TYPE_UINT8);
	} else if (!strcmp(tok, "ldc_type")) {
		get_value((void *)&p->view_type, TYPE_INT32);
	} else if (!strcmp(tok, "ldc_x")) {
		get_value((void *)&p->center_offset.x, TYPE_INT16);
	} else if (!strcmp(tok, "ldc_y")) {
		get_value((void *)&p->center_offset.y, TYPE_INT16);
	} else if (!strcmp(tok, "ldc_ratio")) {
		get_value((void *)&p->ratio, TYPE_INT32);
	} else {
		hit = 0;
	}

	//end:
	return hit;
}

static int parse_chn_panorama_attr(char *tok, MPI_PANORAMA_ATTR_S *p)
{
	//static int idx = 0;
	int hit = 1;

	if (!strcmp(tok, "pano_en")) {
		get_value((void *)&p->enable, TYPE_UINT8);
	} else if (!strcmp(tok, "pano_radius")) {
		get_value((void *)&p->radius, TYPE_UINT16);
	} else if (!strcmp(tok, "pano_curvature")) {
		get_value((void *)&p->curvature, TYPE_UINT16);
	} else if (!strcmp(tok, "pano_ldc")) {
		get_value((void *)&p->ldc_ratio, TYPE_UINT16);
	} else if (!strcmp(tok, "pano_straighten")) {
		get_value((void *)&p->straighten, TYPE_UINT16);
	} else if (!strcmp(tok, "pano_x_offs")) {
		get_value((void *)&p->center_offset.x, TYPE_INT16);
	} else if (!strcmp(tok, "pano_y_offs")) {
		get_value((void *)&p->center_offset.y, TYPE_INT16);
	} else {
		hit = 0;
	}

	//end:
	return hit;
}

static int parse_chn_panning_attr(char *tok, MPI_PANNING_ATTR_S *p)
{
	//static int idx = 0;
	int hit = 1;

	if (!strcmp(tok, "pann_en")) {
		get_value((void *)&p->enable, TYPE_UINT8);
	} else if (!strcmp(tok, "pann_radius")) {
		get_value((void *)&p->radius, TYPE_UINT16);
	} else if (!strcmp(tok, "pann_ldc")) {
		get_value((void *)&p->ldc_ratio, TYPE_UINT16);
	} else if (!strcmp(tok, "pann_hor_strength")) {
		get_value((void *)&p->hor_strength, TYPE_UINT16);
	} else if (!strcmp(tok, "pann_ver_strength")) {
		get_value((void *)&p->ver_strength, TYPE_UINT16);
	} else if (!strcmp(tok, "pann_x_offs")) {
		get_value((void *)&p->center_offset.x, TYPE_INT16);
	} else if (!strcmp(tok, "pann_y_offs")) {
		get_value((void *)&p->center_offset.y, TYPE_INT16);
	} else {
		hit = 0;
	}

	//end:
	return hit;
}

static int parse_chn_surround_attr(char *tok, MPI_SURROUND_ATTR_S *p)
{
	//static int idx = 0;
	int hit = 1;

	if (!strcmp(tok, "surr_en")) {
		get_value((void *)&p->enable, TYPE_UINT8);
	} else if (!strcmp(tok, "surr_rotate")) {
		get_value((void *)&p->rotate, TYPE_INT32);
	} else if (!strcmp(tok, "surr_min_radius")) {
		get_value((void *)&p->min_radius, TYPE_UINT16);
	} else if (!strcmp(tok, "surr_max_radius")) {
		get_value((void *)&p->max_radius, TYPE_UINT16);
	} else if (!strcmp(tok, "surr_ldc")) {
		get_value((void *)&p->ldc_ratio, TYPE_UINT16);
	} else if (!strcmp(tok, "surr_x_offs")) {
		get_value((void *)&p->center_offset.x, TYPE_INT16);
	} else if (!strcmp(tok, "surr_y_offs")) {
		get_value((void *)&p->center_offset.y, TYPE_INT16);
	} else {
		hit = 0;
	}

	//end:
	return hit;
}

static int parse_chn_osd_attr(char *tok, CONF_CASE_OSD_PARAM *p)
{
	static MPI_OSD_OVERLAY_E osd_type = MPI_OSD_OVERLAY_NUM;
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "osd_type")) {
		get_osd_type((void *)&p->osd_attr.osd_type);
		osd_type = p->osd_attr.osd_type;

		hit = 1;

		goto end;
	}

	if (!strcmp(tok, "osd_width")) {
		get_value((void *)&p->osd_attr.size.width, TYPE_UINT16);
	} else if (!strcmp(tok, "osd_height")) {
		get_value((void *)&p->osd_attr.size.height, TYPE_UINT16);
	} else if (!strcmp(tok, "osd_statr_x")) {
		get_value((void *)&p->bind.point.x, TYPE_UINT16);
	} else if (!strcmp(tok, "osd_statr_y")) {
		get_value((void *)&p->bind.point.y, TYPE_UINT16);
	} else {
		hit = 0;
		if (osd_type < MPI_OSD_OVERLAY_NUM) {
			switch (osd_type) {
			case MPI_OSD_OVERLAY_POLYGON:
				hit = parse_osd_polygon_attr(tok, &p->osd_attr.polygon);
				break;
			case MPI_OSD_OVERLAY_LINE:
				hit = parse_osd_line_attr(tok, &p->osd_attr.line);
				break;
			case MPI_OSD_OVERLAY_BITMAP:
				break;
			case MPI_OSD_OVERLAY_BITMAP_BYPASS:
				break;
			default:
				printf("Invalid osd type %d.\n", osd_type);
				hit = 0;
				break;
			}
		}
	}

end:
	return hit;
}

static int parse_chn_vftr_attr(char *tok, CONF_CASE_VFTR_PARAM *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "od_en")) {
		get_value((void *)&p->od_en, TYPE_UINT8);
	} else if (!strcmp(tok, "rms_en")) {
		get_value((void *)&p->rms_en, TYPE_UINT8);
	} else if (!strcmp(tok, "ld_en")) {
		get_value((void *)&p->ld_en, TYPE_UINT8);
	} else if (!strcmp(tok, "td_en")) {
		get_value((void *)&p->td_en, TYPE_UINT8);
	} else if (!strcmp(tok, "md_en")) {
		get_value((void *)&p->md_en, TYPE_UINT8);
	} else if (!strcmp(tok, "ef_en")) {
		get_value((void *)&p->ef_en, TYPE_UINT8);
	} else if (!strcmp(tok, "aroi_en")) {
		get_value((void *)&p->aroi_en, TYPE_UINT8);
	} else if (!strcmp(tok, "pd_en")) {
		get_value((void *)&p->pd_en, TYPE_UINT8);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_dev_path_param(char *tok, CONF_DEV_PARAM *conf)
{
	static INT32 idx = INVALID_PATH_IDX;

	int hit = 0;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "path_idx")) {
		get_value((void *)&idx, TYPE_INT32);

		int found = 0;
		for (int i = 0; i < conf->path_cnt; ++i) {
			if (idx == conf->path[i].path_idx) {
				idx = i;
				found = 1;
				break;
			}
		}

		if (!found) {
			conf->path[conf->path_cnt].path_idx = idx;
			idx = conf->path_cnt;
			++conf->path_cnt;
		}

		hit = 1;

		goto end;
	}

	/* Parae other path parameter for valid paht index */
	if (idx >= MIN_PATH_IDX && idx <= MAX_PATH_IDX) {
		CONF_PATH_PARAM *path = &conf->path[idx];
		hit = 1;

		/* Parse general parameter */
		hit = parse_path_gen_param(tok, &path->gen);
		if (hit) {
			goto end;
		}
	}

end:
	return hit;
}

static int parse_dev_chn_param(char *tok, CONF_DEV_PARAM *conf)
{
	static INT32 c_idx = INVALID_CHN_IDX;

	int hit = 0;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "chn_idx")) {
		get_value((void *)&c_idx, TYPE_INT32);

		int found = 0;
		for (int i = 0; i < conf->chn_cnt; ++i) {
			if (c_idx == conf->chn[i].chn_idx) {
				c_idx = i;
				found = 1;
				break;
			}
		}

		if (!found) {
			conf->chn[conf->chn_cnt].chn_idx = c_idx;
			c_idx = conf->chn_cnt;
			++conf->chn_cnt;
		}

		hit = 1;

		goto end;
	}

	/* Parae other channel parameter for valid channel index */
	if (c_idx >= MIN_CHN_IDX && c_idx <= MAX_CHN_IDX) {
		CONF_CHN_PARAM *chn = &conf->chn[c_idx];

		/* Parse general parameter */
		hit = parse_chn_gen_param(tok, &chn->gen);
		if (hit) {
			goto end;
		}

		/* Parse channel layout parameter */
		hit = parse_chn_layout_param(tok, &chn->layout);
		if (hit) {
			goto end;
		}

		/* Parse window attr */
		hit = parse_win_attr(tok, &chn->win[0]);
		if (hit) {
			goto end;
		}

		/* Parse STITCH parameter */
		hit = parse_chn_stitch_attr(tok, &chn->stitch);
		if (hit) {
			goto end;
		}

		/* Parse LDC parameter */
		hit = parse_chn_ldc_attr(tok, &chn->ldc);
		if (hit) {
			goto end;
		}

		/* Parse Panorama parameter */
		hit = parse_chn_panorama_attr(tok, &chn->panorama);
		if (hit) {
			goto end;
		}

		hit = parse_chn_panning_attr(tok, &chn->panning);
		if (hit) {
			goto end;
		}

		/* Parse Panorama parameter */
		hit = parse_chn_surround_attr(tok, &chn->surround);
		if (hit) {
			goto end;
		}

		/* Parse OSD attributes */
		hit = parse_chn_osd_attr(tok, &chn->osd);
		if (hit) {
			goto end;
		}

		/* Parse VFTR attributes */
		hit = parse_chn_vftr_attr(tok, &chn->vftr);
		if (hit) {
			goto end;
		}
	}

end:
	return hit;
}

static int parse_dev_gen_param(char *tok, MPI_DEV_ATTR_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "hdr_mode")) {
		get_hdr_mode(&p->hdr_mode);
	} else if (!strcmp(tok, "stitch_enable")) {
		get_value((void *)&p->stitch_en, TYPE_UINT8);
	} else if (!strcmp(tok, "eis_enable")) {
		get_value((void *)&p->eis_en, TYPE_UINT8);
		//	} else if (!strcmp(tok, "hdr_enable")) {
		//		get_value((void *)&p->hdr_enable, TYPE_UINT8);
	} else if (!strcmp(tok, "bayer")) {
		get_bayer_phase(&p->bayer);
	} else if (!strcmp(tok, "input_fps")) {
		get_value((void *)&p->fps, TYPE_FLOAT);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_dev_obj_det_param(char *tok, MPI_IVA_OD_PARAM_S *p)
{
	int hit = 1;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "od_qual")) {
		get_value((void *)&p->od_qual, TYPE_UINT8);
	} else if (!strcmp(tok, "od_size_th")) {
		get_value((void *)&p->od_size_th, TYPE_UINT8);
	} else if (!strcmp(tok, "od_sen")) {
		get_value((void *)&p->od_sen, TYPE_UINT8);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_case_param(char *tok, SAMPLE_CONF_S *conf)
{
	int hit = 1;
	CONF_CASE_GEN_PARAM *p = &conf->casegen;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "sid")) {
		get_value((void *)&p->sid, TYPE_INT16);
	} else if (!strcmp(tok, "show_params")) {
		get_value((void *)&p->show_params, TYPE_UINT8);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_vb_conf_param(char *tok, MPI_VB_CONF_S *p)
{
	int hit = 1;

	if (!strcmp(tok, "max_pool_cnt")) {
		get_value((void *)&p->max_pool_cnt, TYPE_INT32);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_vb_pool_param(char *tok, MPI_VB_CONF_S *p)
{
	static MPI_VB_POOL_CONF_S *pool = NULL;

	int hit = 1;

	if (!strcmp(tok, "pool_idx")) {
		int i;

		get_value((void *)&i, TYPE_INT32);

		if (i >= MIN_VB_POOL_IDX && i <= MAX_VB_POOL_IDX) {
			pool = &p->pub_pool[i];
		} else {
			printf("Invalid pool index.\n");
		}
	} else if (!strcmp(tok, "block_size")) {
		get_value((void *)&pool->blk_size, TYPE_UINT32);
	} else if (!strcmp(tok, "block_cnt")) {
		get_value((void *)&pool->blk_cnt, TYPE_UINT32);
	} else if (!strcmp(tok, "pool_name")) {
		char *val = strtok(NULL, " =\n");
		strcpy((char *)pool->name, val);
	} else {
		hit = 0;
	}

	return hit;
}

static int parse_sys_param(char *tok, SAMPLE_CONF_S *conf)
{
	int hit = 0;

	CONF_SYS_PARAM *p = &conf->sys;

	//	printf("tok = |%s|.\n", tok);

	/* Parse VB config */
	hit = parse_vb_conf_param(tok, &p->vb_conf);
	if (hit) {
		goto end;
	}

	/* Parse VB pool parameter */
	hit = parse_vb_pool_param(tok, &p->vb_conf);
	if (hit) {
		goto end;
	}

end:
	return hit;
}

static int parse_dev_param(char *tok, SAMPLE_CONF_S *conf)
{
	static INT32 idx = INVALID_DEV_IDX;

	int hit = 0;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "dev_idx")) {
		get_value((void *)&idx, TYPE_INT32);

		int found = 0;
		for (int i = 0; i < conf->dev_cnt; ++i) {
			if (idx == conf->dev[i].dev_idx) {
				found = 1;
				break;
			}
		}

		if (!found) {
			++conf->dev_cnt;
		}

		conf->dev[idx].dev_idx = idx;

		hit = 1;

		goto end;
	}

	/* Parae other device parameter for valid device index */
	if (idx >= MIN_DEV_IDX && idx <= MAX_DEV_IDX) {
		CONF_DEV_PARAM *p = &conf->dev[idx];

		/* Parse general parameter */
		hit = parse_dev_gen_param(tok, &p->gen);
		if (hit) {
			goto end;
		}

		/* Parse path parameter */
		hit = parse_dev_path_param(tok, p);
		if (hit) {
			goto end;
		}

		/* Parse channel parameter */
		hit = parse_dev_chn_param(tok, p);
		if (hit) {
			goto end;
		}

		/* Parse object detection parameter */
		hit = parse_dev_obj_det_param(tok, &p->obj_det);
		if (hit) {
			goto end;
		}
	}

end:
	return hit;
}

static int parse_enc_chn_param(char *tok, SAMPLE_CONF_S *conf)
{
	static INT32 idx = INVALID_ENC_CHN_IDX;

	int hit = 0;

	//	printf("tok = |%s|.\n", tok);

	if (!strcmp(tok, "enc_idx")) {
		get_value((void *)&idx, TYPE_INT32);

		int found = 0;
		for (int i = 0; i < conf->enc_chn_cnt; ++i) {
			if (idx == conf->enc_chn[i].chn_idx) {
				idx = i;
				found = 1;
				break;
			}
		}

		if (!found) {
			conf->enc_chn[conf->enc_chn_cnt].chn_idx = idx;
			idx = conf->enc_chn_cnt;
			++conf->enc_chn_cnt;
		}

		hit = 1;

		goto end;
	}

	/* Parae other device parameter for valid channel index */
	if (idx >= MIN_ENC_CHN_IDX && idx <= MAX_ENC_CHN_IDX) {
		CONF_ENC_CHN_PARAM *p = &conf->enc_chn[idx];

		/* Parse case channel related parameter */
		hit = parse_chn_case_param(tok, &p->casep);
		if (hit) {
			goto end;
		}

		/* Parse encoder channel attr */
		hit = parse_enc_chn_attr(tok, &p->chn);
		if (hit) {
			goto end;
		}

		/* Parse binding info */
		hit = parse_enc_bind_info(tok, &p->bind_info);
		if (hit) {
			goto end;
		}

		/* Parse video encoder attr */
		hit = parse_enc_venc_attr(tok, &p->venc);
		if (hit) {
			goto end;
		}

		/* Parse video encoder attr ex*/
		hit = parse_enc_venc_attr_ex(tok, &p->venc_ex);
		if (hit) {
			goto end;
		}
	}

end:
	return hit;
}

/**
 * @brief parse 1 parameter
 * @param[in] str oneline parameter in format "key=value"
 * @param[out] conf pointer to configuration struct
 * @return The execution result
 */
static int parse_param(char *str, SAMPLE_CONF_S *conf)
{
	int hit = 0;
	char *tok = strtok(str, " =");

	while (tok != NULL) {
		hit = 0;

		//	printf("tok = |%s|.\n", tok);

		/* Stop parsing this line when comment sign found */
		if (!strncmp(tok, "#", strlen("#"))) {
			hit = 1;
			break;
		}

		/* Parse case general parameter */
		hit = parse_case_param(tok, conf);
		if (hit) {
			goto next;
		}

		/* Parse system parameter */
		hit = parse_sys_param(tok, conf);
		if (hit) {
			goto next;
		}

		/* Parse device parameter */
		hit = parse_dev_param(tok, conf);
		if (hit) {
			goto next;
		}

		/* Parse encoder parameter */
		hit = parse_enc_chn_param(tok, conf);
		if (hit) {
			goto next;
		}

		if (!hit) {
			/* Bypass error for newline sign */
			if (!strcmp(tok, "\n")) {
				hit = 1;
			} else {
				/* Stop parsing when unknown parameter found */
				printf("Unknown parameter: %s\n", tok);
				break;
			}
		}

	next:
		/* Parse other parameters in same line */
		tok = strtok(NULL, " =");
	}

	return hit;
}

/**
 * @brief parse the configuartion file
 * @param[in] filename name of the configuration file
 * @param[out] conf    pointer to configuration struct
 * @return The execution result
 * @retval 0        nothing is parsed
 * @retval positive parsed
 * @retval negative error occurs
 */
static int parse_config_file(char *filename, SAMPLE_CONF_S *conf)
{
	int ret = 0;
	char str[256];
	FILE *fp;

	/* Open config file for parsing */
	fp = fopen(filename, "r");
	if (fp == NULL) {
		printf("Error opening file.\n");
		return -1;
	}

	/* Parse config file line by line */
	while (fgets(str, sizeof(str), fp) != NULL) {
		ret = parse_param(str, conf);

		/* Stop parsing when a unknown parameter found */
		if (!ret) {
			printf("Parsing parameter file failed.\n");
			break;
		}
	}

	fclose(fp);

	return ret;
}

/**
 * @brief parse the .ini name
 * @details the filename will saved at configuration video path 0
 * @param[in] filename name of the .ini file
 * @param[out] conf    pointer to configuration struct
 * @return The execution result
 * @retval 0        nothing is parsed, or error occurs
 * @retval positive parsed
 */
static int parse_ini_name(char *filename, SAMPLE_CONF_S *conf)
{
	UINT32 *idx = &(conf->dev[0].path[0].ini_cnt);
	char *name = conf->dev[0].path[0].ini_files[*idx];

	if (*idx >= SAMPLE_MAX_INI_FILES) {
		printf("Support at most %d ini files\n", SAMPLE_MAX_INI_FILES);
		return 0;
	}

	if (access(filename, F_OK) == -1) {
		printf("file %s doesn't exist\n", filename);
		return 0;
	}

	memcpy(name, filename, 128);
	(*idx)++;
	return 1;
}

/**
 * @brief parse the command arguments
 * @param[in] argc  argument count
 * @param[in] argv  argument vector
 * @param[out] conf pointer to configuration struct
 * @return The execution result
 * @retval 0        nothing is parsed or some error occurs
 * @retval positive parsed
 */
int parse(int argc, char *argv[], SAMPLE_CONF_S *conf)
{
	int c;
	int ret = 0;

	//	printf("Init optind = %d\n", optind);

	while ((c = getopt(argc, argv, "d:s:p:h")) != -1) {
		switch (c) {
		case 'd':
			/* Parse parameter from config file */
			ret = parse_config_file(optarg, conf);
			if (!ret) {
				goto end;
			}
			// printf("argv = %s, optind = %d\n", optarg, optind);
			break;

		case 's':
			ret = parse_ini_name(optarg, conf);
			if (!ret) {
				goto end;
			}
			// printf("argv = %s, optind = %d\n", optarg, optind);

			break;

		case 'p':
			/* Parse parameter from command line */
			ret = parse_param(optarg, conf);
			if (!ret) {
				goto end;
			}
			// printf("argv = %s, optind = %d\n", optarg, optind);
			break;

		case 'h':
			help(argv[0]);
			exit(1);
			break;

		case ':':
			printf("oops\n");
			break;

		case '?':
			if ((optopt == 'd') || (optopt == 'p')) {
				printf("Option -%c requires an argument.\n", optopt);
			} else if (isprint(optopt)) {
				printf("Unknown option '-%c'.\n", optopt);
			} else {
				printf("Unknow option character '\\x%x'.\n", optopt);
			}

		default:
			abort();
		}
	}

end:
	return ret;
}

static void print_mcvc_rc_param(MPI_RC_MODE_E mode, MPI_MCVC_RC_ATTR_S *rc)
{
	switch (mode) {
	case MPI_RC_MODE_VBR:
		printf("VBR: bit_rate = %d, quality_level_index = %d.\n", rc->vbr.max_bit_rate,
		       rc->vbr.quality_level_index);
		break;
	case MPI_RC_MODE_CBR:
		printf("CBR: bit_rate = %d, fluc_level = %d, regression_speed = %d, scene_smooth = %d, max_qp = %d, min_qp = %d.\n",
		       rc->cbr.bit_rate, rc->cbr.fluc_level, rc->cbr.regression_speed, rc->cbr.scene_smooth,
		       rc->cbr.max_qp, rc->cbr.min_qp);
		break;
	case MPI_RC_MODE_CQP:
		printf("CQP: i_frame_qp = %d, p_frame_qp = %d.\n", rc->cqp.i_frame_qp, rc->cqp.p_frame_qp);
		break;
	default:
		printf("Incorrect rate control mode\n");
		break;
	}
}

static void print_vc_rc_param(MPI_VENC_TYPE_E mode, MPI_VC_RC_ATTR_S *rc)
{
	switch (mode) {
	case MPI_RC_MODE_VBR:
		printf("VBR: max_bit_rate = %d, quality_level_index = %d.\n", rc->max_bit_rate,
		       rc->quality_level_index);
		break;
	case MPI_RC_MODE_CBR:
		printf("CBR: bit_rate = %d, max_q_factor = %d, min_q_factor = %d.\n", rc->bit_rate, rc->max_q_factor,
		       rc->min_q_factor);
		break;
	case MPI_RC_MODE_SBR:
		printf("SBR: bit_rate = %d.\n", rc->bit_rate);
		break;
	case MPI_RC_MODE_CQP:
		printf("CQP: q_factor = %d.\n", rc->q_factor);
		break;
	default:
		printf("Incorrect rate control mode.\n");
		break;
	}
}

static void print_venc_attr(MPI_VENC_ATTR_S *p)
{
	switch (p->type) {
	case MPI_VENC_TYPE_H264:
		printf("H264:\n");
		printf("venc_profile = %d, rc_mode = %d, gop_size = %d, frm_rate_o = %d\n", p->h264.profile,
		       p->h264.rc.mode, p->h264.rc.gop, p->h264.rc.frm_rate_o);
		print_mcvc_rc_param(p->h264.rc.mode, &p->h264.rc);
		break;
	case MPI_VENC_TYPE_H265:
		printf("H265:\n");
		printf("venc_profile = %d, rc_mode = %d, gop_size = %d, frm_rate_o = %d\n", p->h265.profile,
		       p->h265.rc.mode, p->h265.rc.gop, p->h265.rc.frm_rate_o);
		print_mcvc_rc_param(p->h265.rc.mode, &p->h265.rc);
		break;
	case MPI_VENC_TYPE_MJPEG:
		printf("MJPEG:\n");
		printf("rc_mode = %d, frm_rate_o = %d\n", p->mjpeg.rc.mode, p->mjpeg.rc.frm_rate_o);
		print_vc_rc_param(p->mjpeg.rc.mode, &p->mjpeg.rc);
		break;
	case MPI_VENC_TYPE_JPEG:
		printf("JPEG: q_factor = %d.\n", p->jpeg.q_factor);
		break;
	default:
		printf("Incorrect encode type.\n");
		break;
	}
}

static void print_chn_laylout(MPI_CHN_LAYOUT_S *p)
{
	int i;

	printf("Channel layout:\n");
	printf("window_num = %d\n", p->window_num);
	for (i = 0; i < p->window_num; i++) {
		printf("window[%d]: x = %d, y = %d, width = %d, height = %d\n",
		i, p->window[i].x, p->window[i].y, p->window[i].width, p->window[i].height);
	}

	printf("\n");
}

static void print_window_attr(int k, MPI_WIN_ATTR_S *p)
{
	printf("Window attr [%d]: path.bmp = %d, fps = %f, view_type = %d.\n",
	       k, p->path.bmp, p->fps, p->view_type);
	printf("                 rotate = %d, mirr_en = %d, flip_en = %d.\n", p->rotate, p->mirr_en, p->flip_en);
	printf("                 roi.x = %d, roi.y = %d, roi.width = %d, roi.height = %d.\n",
	       p->roi.x, p->roi.y, p->roi.width, p->roi.height);
	printf("                 prio = %d, const_qual = %d, dyn_adj = %d, parent = %d.\n",
	                         p->prio, p->const_qual, p->dyn_adj, p->src_id.value);
}

static void print_stitch_attr(MPI_STITCH_ATTR_S *p)
{
	printf("STITCH params:\n");
	printf("Enable = %d\n", p->enable);
	printf("Optical center 0 = (%d, %d)\n", p->center[0].x, p->center[0].y);
	printf("Optical center 1 = (%d, %d)\n", p->center[1].x, p->center[1].y);
	printf("Default index = %d\n", p->dft_dist);
	printf("Table num = %d\n", p->table_num);

	for (int i = 0; i < MPI_STITCH_TABLE_NUM; ++i) {
		MPI_STITCH_DIST_S *dist = &p->table[i];

		printf("--STITCH table %d:\n", i);
		printf("Distance = %d\n", dist->dist);
		printf("Vertical display = %d\n", dist->ver_disp);
		printf("Straighten line  = %d\n", dist->straighten);
		printf("Source image zoom = %d\n", dist->src_zoom);
		printf("Theta 0 = %d, Theta 1 = %d\n", dist->theta[0], dist->theta[1]);
		printf("Radius 0 = %d, Radius 1 = %d\n", dist->radius[0], dist->radius[1]);
		printf("Curvature 0 = %d, Curvature 1 = %d\n", dist->curvature[0], dist->curvature[1]);
		printf("FOV Ratio 0 = %d, Ratio 1 = %d\n", dist->fov_ratio[0], dist->fov_ratio[1]);
		printf("VER Scale 0 = %d, Scale 1 = %d\n", dist->ver_scale[0], dist->ver_scale[1]);
		printf("VER Shift 0 = %d, Shift 1 = %d\n", dist->ver_shift[0], dist->ver_shift[1]);
	}

	printf("\n");
}

static void print_ldc_attr(MPI_LDC_ATTR_S *p)
{
	printf("LDC Attributes:\n");
	printf("LDC enable:%d type %d ratio %d\n", p->enable, p->view_type, p->ratio);
	printf("LDC x %d y %d\n", p->center_offset.x, p->center_offset.y);

	printf("\n");
}

static void print_panorama_attr(MPI_PANORAMA_ATTR_S *p)
{
	printf("PANORAMA Attributes:\n");
	printf("PANO enable:%d radius %d curvature %d straighten %d idc_ratio %d\n", p->enable, p->radius,
	       p->curvature, p->straighten, p->ldc_ratio);
	printf("PANO x %d y %d\n", p->center_offset.x, p->center_offset.y);

	printf("\n");
}

static void print_panning_attr(MPI_PANNING_ATTR_S *p)
{
	printf("PANNING Attributes:\n");
	printf("PANN enable:%d hor_str %d ver_str %d ratio %d\n", p->enable, p->hor_strength, p->ver_strength, p->ldc_ratio);
	printf("PANN x %d y %d\n", p->center_offset.x, p->center_offset.y);

	printf("\n");
}

static void print_surround_attr(MPI_SURROUND_ATTR_S *p)
{
	printf("SURROUND Attributes:\n");
	printf("SURR enable:%d rotate %d min_radius %d max_radius %d idc_ratio %d\n", p->enable, p->rotate,
	       p->min_radius, p->max_radius, p->ldc_ratio);
	printf("SURR x %d y %d\n", p->center_offset.x, p->center_offset.y);

	printf("\n");
}

static void print_osd_attr(CONF_CASE_OSD_PARAM *osd)
{
	printf("OSD Attributes:\n");
	printf("OSD type = %d.\n", osd->osd_attr.osd_type);
	printf("OSD x = %d y = %d width = %d height = %d.\n", osd->bind.point.x, osd->bind.point.y,
	       osd->osd_attr.size.width, osd->osd_attr.size.height);

	switch (osd->osd_attr.osd_type) {
	case MPI_OSD_OVERLAY_POLYGON:
		printf("OSD color %x.\n", osd->osd_attr.polygon.color);
		break;
	case MPI_OSD_OVERLAY_LINE:
		printf("OSD color %x.\n", osd->osd_attr.line.color);
		break;
	case MPI_OSD_OVERLAY_BITMAP:
		break;
	default:
		break;
	}

	printf("\n");
}

static void print_vftr_attr(CONF_CASE_VFTR_PARAM *vftr)
{
	printf("Video feature config:\n");
	printf("od_en = %d ld_en %d\n", vftr->od_en, vftr->ld_en);
	printf("td_en = %d md_en = %d\n", vftr->td_en, vftr->md_en);
	printf("ef_en = %d rms_en = %d\n", vftr->ef_en, vftr->rms_en);
	printf("aroi_en = %d\n", vftr->aroi_en);
}

static void print_obj_det_param(MPI_IVA_OD_PARAM_S *obj)
{
	printf("IVA Object Detection parameters:\n");
	printf("od_qual = %d, od_size_th = %d, od_sen = %d\n", obj->od_qual, obj->od_size_th, obj->od_sen);
}

void show_result(SAMPLE_CONF_S *conf)
{
	int i, j, k;

	printf("Case general parameters:\n");
	printf("sid = %d, show_params = %d.\n", conf->casegen.sid, conf->casegen.show_params);
	printf("\n");

	printf("VB config:\n");
	printf("max pool cnt = %d.\n", conf->sys.vb_conf.max_pool_cnt);
	for (i = 0; i < VB_POOL_NUM; ++i) {
		printf("VB Pool %d:\n", i);
		printf("block size = %d, block cnt = %d, name = %s.\n", conf->sys.vb_conf.pub_pool[i].blk_size,
		       conf->sys.vb_conf.pub_pool[i].blk_cnt, conf->sys.vb_conf.pub_pool[i].name);
	}

	printf("\n");

	for (i = 0; i < conf->dev_cnt; ++i) {
		CONF_DEV_PARAM *dev = &conf->dev[i];

		printf("Video device %d:\n", dev->dev_idx);
		printf("stitch_en = %d, eis_en = %d, hdr_mode = %d, input_frame_rate = %f, bayer = %d.\n",
		       dev->gen.stitch_en, dev->gen.eis_en, dev->gen.hdr_mode, dev->gen.fps, dev->gen.bayer);
		printf("\n");

		print_obj_det_param(&dev->obj_det);

		for (j = 0; j < dev->path_cnt; ++j) {
			CONF_PATH_PARAM *path = &dev->path[j];
			printf("Input path %d:\n", path->path_idx);
			printf("sensor index = %d, res= %dx%d.\n", path->gen.sensor_idx, path->gen.res.width,
			       path->gen.res.height);
		}

		printf("\n");

		for (j = 0; j < dev->chn_cnt; ++j) {
			CONF_CHN_PARAM *chn = &conf->dev[i].chn[j];

			printf("Video channel %d:\n", chn->chn_idx);
			printf("res = %dx%d, fps = %f.\n", chn->gen.res.width, chn->gen.res.height, chn->gen.fps);

			print_chn_laylout(&chn->layout);

			for (k = 0; k < chn->layout.window_num; ++k) {
				print_window_attr(k, &chn->win[k]);
			}

			printf("\n");

			print_stitch_attr(&chn->stitch);

			print_ldc_attr(&chn->ldc);
			print_panorama_attr(&chn->panorama);
			print_panning_attr(&chn->panning);
			print_surround_attr(&chn->surround);

			print_osd_attr(&chn->osd);

			print_vftr_attr(&chn->vftr);

			printf("\n");
		}
	}

	for (i = 0; i < conf->enc_chn_cnt; ++i) {
		CONF_ENC_CHN_PARAM *enc_chn = &conf->enc_chn[i];

		printf("Encoder channel %d:\n", enc_chn->chn_idx);
		printf("General param:\n");
		printf("udpstream = %d, record = %d.\n", enc_chn->casep.udpstream_enable,
		       enc_chn->casep.record_enable);
		printf("client_ip = %s, client_port = %d.\n", enc_chn->casep.client_ip,
		       enc_chn->casep.client_port);
		printf("output_file = %s, frame_num = %d\n", enc_chn->casep.output_file,
		       enc_chn->casep.frame_num);
		printf("Channel attr:\n");
		printf("res = %dx%d.\n", enc_chn->chn.res.width, enc_chn->chn.res.height);
		printf("Binding info:\n");
		printf("bind_dev_idx = %d, bind_chn_idx = %d.\n", enc_chn->bind_info.idx.dev,
		       enc_chn->bind_info.idx.chn);
		printf("Encoder: type = %d\n", enc_chn->venc.type);
		print_venc_attr(&enc_chn->venc);

		printf("\n");
	}
}

/**
 * @brief initialize video path configuration
 * @param[out] p pointer to video path configurations
 */
static void init_path_conf(CONF_PATH_PARAM *p)
{
	MPI_PATH_ATTR_S *gen = &p->gen;
	int i;

	p->path_idx = -1;

	p->ini_cnt = 0;
	for (i = 0; i < SAMPLE_MAX_INI_FILES; ++i) {
		p->ini_files[i] = malloc(128);
		memset(p->ini_files[i], 0, 128);
	}

	gen->sensor_idx = 0;
	gen->res.width = 0;
	gen->res.height = 0;
}

static void init_win_conf(MPI_WIN_ATTR_S *p)
{
	p->path.bmp = 0x0;
	p->fps = 0;
	p->rotate = 0;
	p->mirr_en = 0;
	p->flip_en = 0;
	p->view_type = 0;
	p->roi.x = 0;
	p->roi.y = 0;
	p->roi.width = 0;
	p->roi.height= 0;
	p->prio = 0;
	p->src_id = MPI_INVALID_VIDEO_WIN;
	p->const_qual = 0;
	p->dyn_adj = 0;
}

static void init_chn_conf(CONF_CHN_PARAM *p)
{
	CONF_CASE_VFTR_PARAM *vftr = &p->vftr;
	MPI_CHN_ATTR_S *gen = &p->gen;
	MPI_CHN_LAYOUT_S *layout = &p->layout;
	MPI_WIN_ATTR_S *window = &p->win[0];

	MPI_STITCH_ATTR_S *stitch = &p->stitch;
	MPI_LDC_ATTR_S *ldc = &p->ldc;

	MPI_PANORAMA_ATTR_S *panorama = &p->panorama;
	MPI_PANNING_ATTR_S *panning = &p->panning;
	MPI_SURROUND_ATTR_S *surround = &p->surround;

	p->chn_idx = -1;

	/* Init channel attr */
	gen->res.width = 0;
	gen->res.height = 0;
	gen->fps = 0;

	/* Init channel latout */
	memset(layout, 0, sizeof(MPI_CHN_LAYOUT_S));

	/* Init window attr */
	memset(window, 0, sizeof(MPI_WIN_ATTR_S) * MPI_MAX_VIDEO_WIN_NUM);

	/* Init STITCH attr */
	stitch->enable = 0;
	stitch->center[0].x = 0;
	stitch->center[0].y = 0;
	stitch->center[1].x = 0;
	stitch->center[1].y = 0;
	stitch->dft_dist = 0;
	stitch->table_num = 0;
	stitch->table[0].dist = 0;
	stitch->table[0].ver_disp = 0;
	stitch->table[0].straighten = 0;
	stitch->table[0].src_zoom = 0;
	stitch->table[0].theta[0] = 0;
	stitch->table[0].theta[1] = 0;
	stitch->table[0].radius[0] = 0;
	stitch->table[0].radius[1] = 0;
	stitch->table[0].curvature[0] = 0;
	stitch->table[0].curvature[1] = 0;
	stitch->table[0].fov_ratio[0] = 0;
	stitch->table[0].fov_ratio[1] = 0;
	stitch->table[0].ver_scale[0] = 0;
	stitch->table[0].ver_scale[1] = 0;
	stitch->table[0].ver_shift[0] = 0;
	stitch->table[0].ver_shift[1] = 0;
	stitch->table[1].dist = 0;
	stitch->table[1].ver_disp = 0;
	stitch->table[1].straighten = 0;
	stitch->table[1].src_zoom = 0;
	stitch->table[1].theta[0] = 0;
	stitch->table[1].theta[1] = 0;
	stitch->table[1].radius[0] = 0;
	stitch->table[1].radius[1] = 0;
	stitch->table[1].curvature[0] = 0;
	stitch->table[1].curvature[1] = 0;
	stitch->table[1].fov_ratio[0] = 0;
	stitch->table[1].fov_ratio[1] = 0;
	stitch->table[1].ver_scale[0] = 0;
	stitch->table[1].ver_scale[1] = 0;
	stitch->table[1].ver_shift[0] = 0;
	stitch->table[1].ver_shift[1] = 0;
	stitch->table[2].dist = 0;
	stitch->table[2].ver_disp = 0;
	stitch->table[2].straighten = 0;
	stitch->table[2].src_zoom = 0;
	stitch->table[2].theta[0] = 0;
	stitch->table[2].theta[1] = 0;
	stitch->table[2].radius[0] = 0;
	stitch->table[2].radius[1] = 0;
	stitch->table[2].curvature[0] = 0;
	stitch->table[2].curvature[1] = 0;
	stitch->table[2].fov_ratio[0] = 0;
	stitch->table[2].fov_ratio[1] = 0;
	stitch->table[2].ver_scale[0] = 0;
	stitch->table[2].ver_scale[1] = 0;
	stitch->table[2].ver_shift[0] = 0;
	stitch->table[2].ver_shift[1] = 0;

	ldc->enable = 0;
	ldc->view_type = MPI_LDC_VIEW_TYPE_CROP;
	ldc->center_offset.x = 0;
	ldc->center_offset.y = 0;
	ldc->ratio = 0;

	panorama->enable = 0;
	panorama->center_offset.x = 0;
	panorama->center_offset.y = 0;
	panorama->radius = 0;
	panorama->curvature = 0;
	panorama->straighten = 0;
	panorama->ldc_ratio = 0;

	panning->enable = 0;
	panning->center_offset.x = 0;
	panning->center_offset.y = 0;
	panning->radius = 0;
	panning->hor_strength = 0;
	panning->ver_strength = 0;
	panning->ldc_ratio = 0;

	surround->enable = 0;
	surround->center_offset.x = 0;
	surround->center_offset.y = 0;
	surround->rotate = 0;
	surround->min_radius = 0;
	surround->max_radius = 0;
	panning->ldc_ratio = 0;

	/* Init vftr attr */
	vftr->od_en = 0;
	vftr->rms_en = 0;
	vftr->ld_en = 0;
	vftr->td_en = 0;
	vftr->md_en = 0;
	vftr->ef_en = 0;
	vftr->aroi_en = 0;
}

static void init_enc_chn_conf(CONF_ENC_CHN_PARAM *p)
{
	CONF_CASE_CHN_PARAM *casep = &p->casep;
	MPI_ENC_CHN_ATTR_S *chn = &p->chn;
	MPI_ENC_BIND_INFO_S *info = &p->bind_info;
	MPI_VENC_ATTR_S *venc = &p->venc;
	MPI_VENC_ATTR_EX_S *venc_ex = &p->venc_ex;

	p->chn_idx = -1;

	/* Init case channel parameters */
	casep->frame_num = 0;
	casep->udpstream_enable = 0;
	casep->record_enable = 0;
	casep->client_port = 0;
	casep->client_ip[0] = '\0';
	casep->output_file[0] = '\0';

	/* Init encoder channel attr */
	chn->res.width = 0;
	chn->res.height = 0;
	chn->max_res.width = 0;
	chn->max_res.height = 0;

	/* Init encoder channel binding info */
	info->idx = MPI_VIDEO_CHN(0, 0);

	/* Init video encoder attr */
	memset(venc, 0, sizeof(MPI_VENC_ATTR_S));
	venc->type = MPI_VENC_TYPE_H264;
	venc->h264.profile = MPI_PRFL_BASELINE;
	venc->h264.rc.mode = MPI_RC_MODE_VBR;
	venc->h264.rc.gop = 0;
	venc->h264.rc.frm_rate_o = 0;
	venc->h264.rc.vbr.max_bit_rate = 0;
	venc->h264.rc.vbr.quality_level_index = 0;

	/* Init video encoder attr extend*/
	venc_ex->obs = MPI_VENC_OBS_DISABLE;
}

void init_sys_conf(CONF_SYS_PARAM *conf)
{
	int i;
	MPI_VB_CONF_S *vb_conf = &conf->vb_conf;
	MPI_VB_POOL_CONF_S *pool;

	vb_conf->max_pool_cnt = 0;

	for (i = 0; i < VB_POOL_NUM; ++i) {
		pool = &vb_conf->pub_pool[i];

		pool->blk_size = 0;
		pool->blk_cnt = 0;
		pool->name[0] = '\0';
	}
}

/**
 * Init Rule:
 * (1) Enable bit always set to 0.
 * (2) Use common/normal setting for enum. ex: op_mode = MPI_OP_MODE_NORMAL.
 */
void init_conf(SAMPLE_CONF_S *conf)
{
	int i, j, k;
	CONF_CASE_GEN_PARAM *casegen;

	conf->dev_cnt = 0;
	conf->enc_chn_cnt = 0;

	casegen = &conf->casegen;

	casegen->sid = SAMPLE_CASE_NONE; /* exception */
	casegen->show_params = 0;

	init_sys_conf(&conf->sys);

	for (i = 0; i < DEV_NUM; ++i) {
		CONF_DEV_PARAM *dev = &conf->dev[i];

		dev->dev_idx = -1;
		dev->path_cnt = 0;
		dev->chn_cnt = 0;

		/* Init device attr */
		dev->gen.hdr_mode = MPI_HDR_MODE_NONE;
		dev->gen.stitch_en = 0;
		dev->gen.eis_en = 0;
		dev->gen.fps = 0.0;
		dev->gen.bayer = MPI_BAYER_PHASE_NUM; /* TODO: */
		dev->gen.path.bmp = 0x0;

		/* Init path attr */
		for (j = 0; j < PATH_NUM; ++j) {
			CONF_PATH_PARAM *path = &dev->path[j];

			init_path_conf(path);
		}

		/* Init channel attr */
		for (j = 0; j < CHN_NUM; ++j) {
			CONF_CHN_PARAM *chn = &dev->chn[j];

			init_chn_conf(chn);
			/* Init window attr */
			for (k = 0; k < WINDOW_NUM; ++k) {
				MPI_WIN_ATTR_S *win = &dev->chn[j].win[k];

				init_win_conf(win);
			}
		}
	}

	for (i = 0; i < ENC_CHN_NUM; ++i) {
		CONF_ENC_CHN_PARAM *enc_chn = &conf->enc_chn[i];

		init_enc_chn_conf(enc_chn);
	}
}

void help(char *str)
{
	printf("USAGE:\n");
	printf("\t%s [-h] [-d case config] {[-s sensorIni0]...[-s sensorIni1]} {[-p Param1=Value1]...[-p ParamM=ValueM]}\n",
	       str);
	printf("\n");
	printf("EXAMPLE:\n");
	printf("\t%s -d case_config/case_config_1\n", str);
	printf("\n");
	printf("OPTION:\n");
	printf("\t'-d' Select configuration file\n");
	printf("\n");
	printf("\t'-s' Select sensor ini file (default /system/mpp/script/sensor_0.ini)\n");
	printf("\n");
	printf("\t'-p' Set parameter <ParamM> to <ValueM>\n");
	printf("\n");
	printf("\t'-h' Help\n");
	printf("\n");
}

#if 0
/**
 * void main(void)
 * main entry function
 */
int main(int argc, char *argv[])
{
	init_conf(&g_conf);

	parse(argc, argv, &g_conf);

	if (g_conf.casepram.show_params == 1) {
		show_result(&g_conf);
	}
	return 0;
}
#endif
