/******************************************************************************
*
* Copyright (c) AUGENTIX Inc. - All Rights Reserved
*
* Unauthorized copying of this file, via any medium is strictly prohibited.
*
* Proprietary and confidential.
*
******************************************************************************/

#ifndef IVA_CONFIG_H_
#define IVA_CONFIG_H_

#include "mpi_types.h"

#define MAX_MD_RGN_NUM 64

typedef enum { CFG_IVA_MD_MODE_AREA, CFG_IVA_MD_MODE_ENERGY } DEMO_CFG_IVA_MD_MODE_E;

typedef enum { AGTX_IVA_MD_DET_NORMAL, AGTX_IVA_MD_DET_SUBTRACT } DEMO_CFG_IVA_MD_DET_E;

typedef enum {
	DEMO_SW_EVENT_TRIG_TYPE_NONE,
	DEMO_SW_EVENT_TRIG_TYPE_IVA_MD_NEGATIVE,
	DEMO_SW_EVENT_TRIG_TYPE_IVA_MD_POSITIVE,
	DEMO_SW_EVENT_TRIG_TYPE_IVA_TD_NEGATIVE,
	DEMO_SW_EVENT_TRIG_TYPE_IVA_TD_POSITIVE,
	DEMO_SW_EVENT_TRIG_TYPE_NUM
} DEMO_SW_EVENT_TRIG_TYPE_E;

typedef struct {
	INT32 enabled;
	INT32 en_shake_det;
	INT32 en_crop_outside_obj;
	INT32 od_qual;
	INT32 od_track_refine;
	INT32 od_size_th;
	INT32 od_sen;
	INT32 en_stop_det;
} DEMO_CFG_IVA_OD_S;

typedef struct {
	DEMO_CFG_IVA_MD_MODE_E mode;
	DEMO_CFG_IVA_MD_DET_E det_method;
	INT32 ey; /* End coordinates of detection region. (inclusive) */
	INT32 ex; /* End coordinates of detection region. (inclusive) */
	INT32 id;
	INT32 sx; /* Start coordinates of detection region. (inclusive) */
	INT32 sy; /* Start coordinates of detection region. (inclusive) */
	INT32 sens;
	INT32 max_spd;
	INT32 min_spd;
	INT32 obj_life_th;
} DEMO_CFG_IVA_MD_REGION_S;

typedef struct {
	INT32 enabled;
	INT32 en_rgn;
	INT32 en_skip_shake;
	INT32 en_skip_pd;
	INT32 rgn_cnt;
	DEMO_CFG_IVA_MD_MODE_E mode;
	DEMO_CFG_IVA_MD_DET_E det_method;
	INT32 sens;
	INT32 alarm_buffer;
	INT32 max_spd;
	INT32 min_spd;
	INT32 obj_life_th;
	DEMO_CFG_IVA_MD_REGION_S rgn_list[MAX_MD_RGN_NUM];
} DEMO_CFG_IVA_MD_S;

INT32 demo_apply_od(UINT32 dev_idx, UINT32 chn_idx, DEMO_CFG_IVA_OD_S *od, INT32 enable_change, UINT8 fps);
INT32 demo_apply_md(UINT32 dev_idx, UINT32 chn_idx, UINT32 width, UINT32 height, DEMO_CFG_IVA_MD_S *md,
                    DEMO_CFG_IVA_MD_S *md_old, INT32 enable_change);
INT32 demo_start_all_iva(UINT32 dev_idx, UINT16 chn_width, UINT16 chn_height);
INT32 demo_close_all_iva(UINT32 dev_idx);
VOID demo_md_cb(uint8_t alarm);

#endif
