#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>

#include "sample_sys.h"
#include "parse.h"

#ifdef MPI_AVFTR_DEMO
#include "mtk_common.h"
#include <assert.h>

#include "video_ftr.h"
#include "av_conn.h"
#include "video_md.h"
#include "video_aroi.h"
#include "video_od.h"
#include "video_vdbg.h"
#include "sample_iva.h"

INT32 g_avftrUnxSktClientFD = 0; //Unix Socket FD
INT32 g_avftrResShmClientFD = 0; //Shared memory for result FD
AV_FTR_CTX_S *g_avftr_res_shm_client = NULL;
MPI_WIN g_iva_idx = { {} };
DEMO_CFG_IVA_MD_S g_md = {};
#endif

#define DEBUG
int g_debuglevel = 0;

#ifdef DEBUG
// extern int g_debuglevel;
#define printd(level, x) (level > g_debuglevel) ? 0 : printf x
#else
#define printd(level, x)
#endif

typedef int (*SampleFunction)(SAMPLE_CONF_S *const conf);

int g_argc;
char **g_argv;

SAMPLE_CONF_S g_conf = { { 0 } };
MPI_DEV g_dev_idx;

int SAMPLE_normalStream(SAMPLE_CONF_S *const conf);

SampleFunction sample_list[] = {
	NULL, /* 0 */
	SAMPLE_normalStream, /* 1 */
};

static void handleSigInt(int signo)
{
	//	UINT32 idx = 0;

	if (signo == SIGINT) {
		printf("Caught SIGINT!\n");
	} else if (signo == SIGTERM) {
		printf("Caught SIGTERM!\n");
	} else {
		perror("Unexpected signal!\n");
		exit(1);
	}

	/* Remove pthread_join, which is not signal-safe function */
	switch (g_conf.casegen.sid) {
	case SAMPLE_CASE_NORMAL_STREAM:
		for (int idx = 0; idx < g_conf.enc_chn_cnt; idx++) {
			g_bsb_run[idx] = 0;
		}

		break;
	default:
		break;
	}
}

int SAMPLE_normalStream(SAMPLE_CONF_S *const conf)
{
	UINT32 stream_idx = 0;
	INT32 ret = MPI_FAILURE;
	INT32 frame_num_n1 = 0;
#ifdef MPI_AVFTR_DEMO
	INT8 retry = 3;
	INT8 err = 0;
	// For AVFTR Client

	if (AV_FTR_initServer() < 0) {
		printf("[MPI_AVFTR_DEMO]Init AVFTR server failed\n");
		return MPI_FAILURE;
	}
	printf("[MPI_AVFTR_DEMO] Init AVFTR server successfully !\n");
#endif //MPI_AVFTR_DEMO

	ret = SAMPLE_startStream(g_dev_idx, conf);
	if (ret != MPI_SUCCESS) {
		return 0;
	}

	SAMPLE_initGetStream();

#ifdef MPI_AVFTR_DEMO
	while (AV_FTR_initClient(&g_avftrResShmClientFD, &g_avftrUnxSktClientFD, &g_avftr_res_shm_client) != 0) {
		if (retry-- >= 0) {
			sleep(1);
			printf("[MPI_AVFTR_DEMO] Init AVFTR client failed, try init again ! \n");
		} else {
			printf("[MPI_AVFTR_DEMO] Init AVFTR client failed triple times, please check AVFTR server.");
			return -1;
		}
	}
	printf("[MPI_AVFTR_DEMO] Init AVFTR server successfully !\n");
#endif //MPI_AVFTR_DEMO

	/* Be noted: Encode chn is one-by-one mapped to stream in mpi_stream */
	for (stream_idx = 0; stream_idx < conf->enc_chn_cnt; ++stream_idx) {
		printf("[SAMPLE] %s: start get stream from channel %d\n", __func__, stream_idx);
		ret = SAMPLE_startGetStream(&conf->enc_chn[stream_idx]);
		frame_num_n1 |= (conf->enc_chn[stream_idx].casep.frame_num == -1);

		printf("[SAMPLE] %s: start Encode channel %d\n", __func__, stream_idx);
		ret = SAMPLE_startEncChn(stream_idx, &conf->enc_chn[stream_idx]);
		if (ret != MPI_SUCCESS) {
			return 0;
		}
	}
#ifdef MPI_AVFTR_DEMO
	//if (VIDEO_FTR_regOdCallback(MPI_VIDEO_WIN(conf->dev[0].dev_idx, 0, 0), &demo_od_cb) < 0) {
	//	printf("[MPI_AVFTR_DEMO] VIDEO_FTR_regOdCallback failed. \n");
	//} else {
	//	printf("[MPI_AVFTR_DEMO] VIDEO_FTR_regOdCallback success. \n");
	//}

	if (VIDEO_FTR_regMdCallback(MPI_VIDEO_WIN(conf->dev[0].dev_idx, 0, 0), &demo_md_cb) < 0) {
		printf("[MPI_AVFTR_DEMO] VIDEO_FTR_regMdCallback failed. \n");
	} else {
		printf("[MPI_AVFTR_DEMO] VIDEO_FTR_regMdCallback success. \n");
	}

	ret = demo_start_all_iva(conf->dev[0].dev_idx, 1920, 1080);
	if (ret < 0) {
		printf("[MPI_AVFTR_DEMO] Cannot Start all iva.\n");
		return ret;
	} else {
		printf("[MPI_AVFTR_DEMO] Excute demo_start_all_iva() successfully\n");
	}
#endif //MPI_AVFTR_DEMO

	int flag = 0;

	do {
		usleep(300000);
		flag = 0;

		for (stream_idx = 0; stream_idx < conf->enc_chn_cnt; ++stream_idx) {
			flag |= g_bsb_run[stream_idx];
		}

	} while (flag);

#ifdef MPI_AVFTR_DEMO
	ret = demo_close_all_iva(conf->dev[0].dev_idx);
	if (ret < 0) {
		printf("[MPI_AVFTR_DEMO] Cannot Stop all iva.\n");
		return ret;
	} else {
		printf("[MPI_AVFTR_DEMO] Excute demo_stop_all_iva() successfully\n");
	}
#endif //MPI_AVFTR_DEMO

	for (stream_idx = 0; stream_idx < conf->enc_chn_cnt; ++stream_idx) {
		SAMPLE_stopGetStream(&conf->enc_chn[stream_idx]);
		SAMPLE_stopEncChn(stream_idx, &conf->enc_chn[stream_idx]);
	}

#ifdef MPI_AVFTR_DEMO
	/* Unregister from video server and stop it */
	err = AV_FTR_exitClient(&g_avftrResShmClientFD, &g_avftrUnxSktClientFD, &g_avftr_res_shm_client);
	if (err) {
		printf("[MPI_AVFTR_DEMO] Disconnecting from VFTR server failed.\n");
		return -1;
	}
	printf("[MPI_AVFTR_DEMO] VFTR server dis-connected.\n");
#endif //MPI_AVFTR_DEMO

	SAMPLE_exitGetStream();

	SAMPLE_stopStream(g_dev_idx, conf);

#ifdef MPI_AVFTR_DEMO
	if (AV_FTR_exitServer() < 0) {
		printf("[MPI_AVFTR_DEMO] Exit AVFTR server fail !\n");
	}
	printf("[MPI_AVFTR_DEMO] Exit AVFTR server successfully !\n");
#endif /* MPI_AVFTR_DEMO */

	return 0;
}

#ifdef MPI_AVFTR_DEMO

INT32 demo_apply_od(UINT32 dev_idx, UINT32 chn_idx, DEMO_CFG_IVA_OD_S *od, INT32 enable_change, UINT8 fps)
{
	INT32 ret = 0;
	VIDEO_FTR_OD_PARAM_S vftr_od = { 0 };
	MPI_WIN idx = MPI_VIDEO_WIN(dev_idx, chn_idx, 0);

	/*if enable changed,enable or disable OD*/
	if (enable_change && od->enabled) {
		ret = VIDEO_FTR_enableOd(idx);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
	} else if (enable_change && !od->enabled) {
		ret = VIDEO_FTR_disableOd(idx);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
	}

	ret = VIDEO_FTR_getOdParam(idx, &vftr_od);
	if (ret != VIDEO_FTR_SUCCESS) {
		return -1;
	}

#define VFTR_OD_MAX_DETECTION_SEC 3
#define VFTR_OD_MIN_DETECTION_SEC 0
#define VFTR_OD_DETECTION_SECOND 0.9 //Recommend Default
#define VFTR_OD_DETECTION_PERCENT 70 //Recommend Default

#define VFTR_OD_MAX_TRACK_REFINE_SEC 2
#define VFTR_OD_MIN_TRACK_REFINE_SEC 0
#define VFTR_OD_TRACK_REFINE_SECOND 0.267 //Recommend Default
#define VFTR_OD_TRACK_REFINE_PERCENT 86 //Recommend Default
//1-VFTR_OD_TRACK_REFINE_SECOND/(VFTR_OD_MAX_TRACK_REFINE_SEC-VFTR_OD_MIN_TRACK_REFINE_SEC)

	int od_qual_t = MPI_IVA_OD_MAX_QUA + 1 - (fps*(100-od->od_qual)
	              *(VFTR_OD_MAX_DETECTION_SEC-VFTR_OD_MIN_DETECTION_SEC))/100;

	if (od_qual_t < MPI_IVA_OD_MIN_QUA) {
		od_qual_t = MPI_IVA_OD_MIN_QUA;
	} else if (od_qual_t > MPI_IVA_OD_MAX_QUA) {
		od_qual_t = MPI_IVA_OD_MAX_QUA;
	}

	int od_track_refine_t = MPI_IVA_OD_MAX_TRACK_REFINE + 1 - (fps*(100-od->od_track_refine)
	                      *(VFTR_OD_MAX_TRACK_REFINE_SEC-VFTR_OD_MIN_TRACK_REFINE_SEC))/100;

	if (od_track_refine_t < MPI_IVA_OD_MIN_TRACK_REFINE) {
		od_track_refine_t = MPI_IVA_OD_MIN_TRACK_REFINE;
	} else if (od_track_refine_t > MPI_IVA_OD_MAX_TRACK_REFINE) {
		od_track_refine_t = MPI_IVA_OD_MAX_TRACK_REFINE;
	}

	vftr_od.od_param.od_qual = od_qual_t;
	vftr_od.od_param.od_track_refine = od_track_refine_t;
	vftr_od.od_param.od_size_th = od->od_size_th * MPI_IVA_OD_MAX_OBJ_SIZE / 100;
	vftr_od.od_param.od_sen = od->od_sen * MPI_IVA_OD_MAX_SEN / 100;
	vftr_od.od_param.en_stop_det = od->en_stop_det;
	vftr_od.en_crop_outside_obj = od->en_crop_outside_obj;

	ret = VIDEO_FTR_setOdParam(idx, &vftr_od);

	return 0;
}

INT32 demo_apply_md(UINT32 dev_idx, UINT32 chn_idx, UINT32 width, UINT32 height, DEMO_CFG_IVA_MD_S *md,
                    DEMO_CFG_IVA_MD_S *md_old, INT32 enable_change)
{
	INT32 ret = 0;
	INT32 i = 0;
	INT32 j = 0;
	VIDEO_FTR_MD_PARAM_S vftr_md;
	static VIDEO_FTR_MD_PARAM_S vftr_md_old = { 0 };
	vftr_md.duration = md->alarm_buffer; // VIDEO_FTR_JIF_HZ (unit: 10ms);
	vftr_md.en_skip_shake = md->en_skip_shake;
	vftr_md.en_skip_pd = md->en_skip_pd;

	MPI_WIN idx = MPI_VIDEO_WIN(dev_idx, chn_idx, 0);

	/*if enable changed,enable or disable TD*/
	if (enable_change && md->enabled) {
		ret = VIDEO_FTR_enableMd(idx);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
	} else if (enable_change && !md->enabled) {
		ret = VIDEO_FTR_disableMd(idx);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
	}

	ret = VIDEO_FTR_getMdParam(idx, &vftr_md_old);
	if (ret != VIDEO_FTR_SUCCESS) {
		return -1;
	}

	ret = VIDEO_FTR_setMdParam(idx, &vftr_md);
	if (ret != VIDEO_FTR_SUCCESS) {
		return -1;
	}

#define MD_ENERGY_TH_V_REF_RATIO (15) /* FIXME: Tuning the featurelib or formula */
#define MD_ENERGY_TH_V_REF_RATIO_MAX (255)

	vftr_md.md_param.region_num = md->rgn_cnt;
	for (i = 0; i < md->rgn_cnt; i++) {
		//Convert from percent to actually point
		vftr_md.md_param.attr[i].pts.sx = (width * md->rgn_list[i].sx / 100);
		vftr_md.md_param.attr[i].pts.sy = (height * md->rgn_list[i].sy / 100);
		vftr_md.md_param.attr[i].pts.ex = (width * md->rgn_list[i].ex / 100);
		vftr_md.md_param.attr[i].pts.ey = (height * md->rgn_list[i].ey / 100);
		vftr_md.md_param.attr[i].thr_v_obj_max = md->rgn_list[i].max_spd;
		vftr_md.md_param.attr[i].thr_v_obj_min = md->rgn_list[i].min_spd;
		vftr_md.md_param.attr[i].obj_life_th = md->rgn_list[i].obj_life_th;
		vftr_md.md_param.attr[i].det_method =
		        (md->rgn_list[i].det_method == AGTX_IVA_MD_DET_NORMAL) ? MD_DET_NORMAL : MD_DET_SUBTRACT;
		vftr_md.md_param.attr[i].md_mode =
		        (md->rgn_list[i].mode == CFG_IVA_MD_MODE_AREA) ?
		                MD_MOVING_AREA :
		                (md->rgn_list[i].mode == CFG_IVA_MD_MODE_ENERGY) ? MD_MOVING_ENERGY : MD_MOVING_AREA;
		if (md->rgn_list[i].mode == CFG_IVA_MD_MODE_AREA) {
			vftr_md.md_param.attr[i].thr_v_reg =
			        ((width * height / 100) * (100 - md->rgn_list[i].sens)) / 1000;
		} else { //CFG_IVA_MD_MODE_MOVING_ENERGY
			vftr_md.md_param.attr[i].thr_v_reg =
			        (((((width * height) / 100) * md->rgn_list[i].max_spd) / MD_ENERGY_TH_V_REF_RATIO) *
			         (100 - md->rgn_list[i].sens)) /
			        1000;
		}
	}

	for (i = 0; i < md_old->rgn_cnt; i++) {
		ret = VIDEO_FTR_rmMdRoi(idx, (uint8_t)md_old->rgn_list[i].id);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
	}

	/*Apply new ROI */
	INT32 final_ret = 0;
	for (i = 0; i < md->rgn_cnt; i++) {
		ret = VIDEO_FTR_addMdRoi(idx, &vftr_md.md_param.attr[i], (UINT8 *)&md->rgn_list[i].id);
		if (ret != VIDEO_FTR_SUCCESS) {
			final_ret = 1;
			break;
		}
	}

	/* Error handling */
	if (final_ret) {
		/* Remove newly added ROI */
		for (j = 0; j < i; j++) {
			ret = VIDEO_FTR_rmMdRoi(idx, md->rgn_list[j].id);
			if (ret != VIDEO_FTR_SUCCESS) {
				return -1;
			}
		}
		/* Add old ROI Here should not return fail as it is from old setting */
		for (i = 0; i < vftr_md_old.md_param.region_num; i++) {
			ret = VIDEO_FTR_addMdRoi(idx, &vftr_md_old.md_param.attr[i],
			                         (UINT8 *)&vftr_md_old.md_param.attr[i].id);
			if (ret != VIDEO_FTR_SUCCESS) {
				return -1;
			}
		}
		/* Apply old alarm buff setup */
		ret = VIDEO_FTR_setMdParam(idx, &vftr_md_old);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
		return -1;
	}

	memcpy(&vftr_md_old, &vftr_md, sizeof(VIDEO_FTR_MD_PARAM_S)); // Save md parameters

	return 0;
}

INT32 demo_close_all_iva(UINT32 dev_idx)
{
	UINT32 chn_idx = 0; //iva support one channel only
	MPI_WIN idx = MPI_VIDEO_WIN(dev_idx, chn_idx, 0);
	const DEMO_CFG_IVA_MD_S *md = &g_md;
	INT32 ret = 0;
	INT32 i = 0;

	/*remove old ROI*/
	for (i = 0; i < md->rgn_cnt; i++) {
		ret = VIDEO_FTR_rmMdRoi(idx, md->rgn_list[i].id);
		if (ret != VIDEO_FTR_SUCCESS) {
			return -1;
		}
	}

	ret = VIDEO_FTR_disableMd(idx);
	if (ret != VIDEO_FTR_SUCCESS) {
		return -1;
	}

	ret = VIDEO_FTR_disableOd(idx);
	if (ret < 0) {
		return ret;
	}

	ret = VIDEO_FTR_exitIva(idx);
	if (ret < 0) {
		SYS_TRACE("Cannot exit VFTR_runIva thread for WIN:%x\n", idx.value);
	}

	return ret;
}

INT32 demo_start_all_iva(UINT32 dev_idx, UINT16 chn_width, UINT16 chn_height)
{
	UINT32 chn_idx = 0; //iva support one channel only
	UINT32 win_idx = 0; //iva support one window only
	INT32 ret = 0;
	DEMO_CFG_IVA_MD_S md = { 0 };
	DEMO_CFG_IVA_OD_S od = { 0 };
	MPI_WIN g_iva_idx = MPI_VIDEO_WIN(dev_idx, chn_idx, win_idx);
	MPI_WIN idx = g_iva_idx;
	DEMO_CFG_IVA_MD_S *md_old = &g_md;

	memset(&md, 0, sizeof(DEMO_CFG_IVA_MD_S));
	memset(&od, 0, sizeof(DEMO_CFG_IVA_OD_S));

	od.enabled = 1;
	od.en_crop_outside_obj = 1;
	od.en_shake_det = 1;
	od.en_stop_det = 0;
	od.od_qual = 70;
	od.od_sen = 99;
	od.od_size_th = 6;
	od.od_track_refine = 86;

	//In cfg_apply_od UINT8 fps = 30
	ret = demo_apply_od(dev_idx, chn_idx, &od, 1, 30); //Note: fps should match with case_config setting as well
	if (ret < 0) {
		return ret;
	}

	md.enabled = 1;
	md.en_rgn = 1;
	md.en_skip_shake = 1;
	md.en_skip_pd = 0;
	md.rgn_cnt = 1;
	md.mode = (DEMO_CFG_IVA_MD_MODE_E)CFG_IVA_MD_MODE_ENERGY;
	md.det_method = (DEMO_CFG_IVA_MD_DET_E)AGTX_IVA_MD_DET_NORMAL;
	md.sens = 100;
	md.alarm_buffer = 0;
	md.max_spd = 255;
	md.min_spd = 5;
	md.obj_life_th = 32;
	md.rgn_list[0].mode = CFG_IVA_MD_MODE_ENERGY;
	md.rgn_list[0].det_method = AGTX_IVA_MD_DET_NORMAL;
	md.rgn_list[0].ey = 70;
	md.rgn_list[0].ex = 70;
	md.rgn_list[0].id = 0;
	md.rgn_list[0].sx = 0;
	md.rgn_list[0].sy = 0;
	md.rgn_list[0].sens = 100;
	md.rgn_list[0].max_spd = 255;
	md.rgn_list[0].min_spd = 5;
	md.rgn_list[0].obj_life_th = 32;

	/*put empty md config that don't remove any ROI*/
	ret = demo_apply_md(dev_idx, chn_idx, (UINT32)chn_width, (UINT32)chn_height, &md, md_old, 1);
	if (ret < 0) {
		return ret;
	}

	memcpy(&md_old, &md, sizeof(DEMO_CFG_IVA_MD_S)); // Save md setting if apply successfully

	ret = VIDEO_FTR_runIva(idx);
	if (ret < 0) {
		printf("[MPI_AVFTR_DEMO] Cannot create VFTR_runIva thread for WIN:%x\n", idx.value);
		return ret;
	}

	return 0;
}

void demo_md_cb(uint8_t alarm)
{
	static time_t duration;

	time_t t = time(0);

	printf("[MPI_AVFTR_DEMO] In %s, cb occurred ! alarm = %d\n", __FUNCTION__, (int)alarm);
	if (time(0) < duration + 2) {
		return;
	}

	duration = t;

	if (alarm) {
		switch (alarm) {
		case DEMO_SW_EVENT_TRIG_TYPE_IVA_MD_NEGATIVE:
			printf("[MPI_AVFTR_DEMO] MD CB NEG Alarm !");
			break;
		case DEMO_SW_EVENT_TRIG_TYPE_IVA_MD_POSITIVE:
			printf("[MPI_AVFTR_DEMO] MD CB POS Alarm !");
			break;
		case DEMO_SW_EVENT_TRIG_TYPE_IVA_TD_NEGATIVE:
			printf("[MPI_AVFTR_DEMO] TD CB NEG Alarm !");
			break;
		case DEMO_SW_EVENT_TRIG_TYPE_IVA_TD_POSITIVE:
			printf("[MPI_AVFTR_DEMO] TD CB POS Alarm !");
			break;
		default:
			printf("[MPI_AVFTR_DEMO] MD CB function known trigger type !");
		}
	}

	return;
}

#endif //MPI_AVFTR_DEMO

int main(int argc, char **argv)
{
	g_argc = argc;
	g_argv = argv;
	g_dev_idx = MPI_VIDEO_DEV(0);

	init_conf(&g_conf);

	if (!parse(argc, argv, &g_conf)) {
		return -1;
	}

	if (g_conf.casegen.show_params == 1) {
		show_result(&g_conf);
	}

	if (signal(SIGINT, handleSigInt) == SIG_ERR) {
		perror("Cannot handle SIGINT!\n");
		exit(1);
	}

	printf("running sample_list[%d](*g_conf)\n", g_conf.casegen.sid);

	sample_list[g_conf.casegen.sid](&g_conf);

	printf("\n");

	return 0;
}
