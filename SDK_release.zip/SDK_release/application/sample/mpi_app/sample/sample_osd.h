#ifndef SAMPLE_OSD_H_
#define SAMPLE_OSD_H_

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /**< __cplusplus */

#include "mpi_types.h"
#include "mpi_common.h"
#include "mpi_sys.h"
#include "mpi_dev.h"
#include "mpi_enc.h"
#include "mpi_osd.h"
#include "mpi_iva.h"
#include <pthread.h>

#define displayable_character_numbers 104 /**< Number of displayable ASCII character. */
#define LOGO_OSD_SIZE_WIDTH 544 /**< Default width of logo OSD region. */
#define LOGO_OSD_SIZE_HEIGHT 128 /**< Default height of logo OSD region. */
#define TIME_OSD_SIZE_WIDTH 416 /**< Default width of time OSD region. */
#define TIME_OSD_SIZE_HEIGHT 48 /**< Default height of time OSD region. */
#define NUMBER_OSD_SIZE_WIDTH 160 /**< Default width of number OSD region. */
#define NUMBER_OSD_SIZE_HEIGHT 48 /**< Default height of number OSD region. */
#define SAMPLE_OSD_ON /**< Flag of enable default OSD. */

/**
* @brief Struct for ASCII index.
*/
typedef struct {
	UINT32 image_offset;
	UINT32 image_size;
	UINT32 image_width;
	UINT32 image_height;
} ASCII_INDEX;

INT32 SAMPLE_stopOsd(MPI_CHN chn_idx);
void SAMPLE_getAYUVfileinfo(void);
INT32 SAMPLE_createOsdRegion(MPI_CHN chn_idx, INT32 output_num, UINT16 width, UINT16 height);
void SAMPLE_initOsdhandle(void);
void SAMPLE_free_memory(void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /**< __cplusplus */

#endif /**< SAMPLE_OSD_H_ */
