#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#include "mpi_common.h"
#include "mpi_sys.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <pthread.h>

#if 0
/**
 * @brief Start streaming.
 * @see SAMPLE_stopChannel()
 * @return The execution result.
 */
INT32 SAMPLE_startChannel(void)
{
	INT32       ret = MPI_FAILURE;
	MPI_DEV dev_idx = 0;
	MPI_CHN chn_idx = MPI_VIDEO_CHN(dev_idx, 0);

	ret = MPI_startChn(chn_idx);
	if (ret != MPI_SUCCESS) {
		printf("Start video channel %d failed.\n", chn_idx);
		return MPI_FAILURE;
	}

	printf("Start streaming successed!\n");
	return MPI_SUCCESS;
}

/**
 * @brief Stop streaming.
 * @see SAMPLE_startChannel()
 * @return The execution result.
 */
INT32 SAMPLE_stopChannel(void)
{
	INT32       ret = MPI_FAILURE;
	MPI_DEV dev_idx = 0;
	MPI_CHN chn_idx = MPI_VIDEO_CHN(dev_idx, 0);

	ret = MPI_stopChn(chn_idx);
	if (ret != MPI_SUCCESS) {
		printf("Stop video channel %d failed.\n", chn_idx);
		return MPI_FAILURE;
	}

	printf("Stop streaming successed!\n");
	return MPI_SUCCESS;
}

/**
 * @brief Verify the MPI to set/get DBC attribute.
 * @return The execution result.
 */
INT32 SAMPLE_setDbcAttr(const MPI_DBC_ATTR_S *dbc_attr)
{
	INT32         ret = MPI_FAILURE;
	MPI_DEV   dev_idx = 0;
	MPI_PATH path_idx = MPI_INPUT_PATH(dev_idx, 0);

	MPI_DBC_ATTR_S attr;

	ret = MPI_setDbcAttr(path_idx, dbc_attr);
	if (ret != MPI_SUCCESS) {
		printf("Set DBC attr failed.\n");
		return MPI_FAILURE;
	}

	ret = MPI_getDbcAttr(path_idx, &attr);
	if (ret != MPI_SUCCESS) {
		printf("Get DBC attr failed.\n");
		return MPI_FAILURE;
	}

	printf("Set DBC attr successed!\n");
	return MPI_SUCCESS;
}
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
