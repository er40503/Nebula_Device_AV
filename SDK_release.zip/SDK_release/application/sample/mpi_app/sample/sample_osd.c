#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /**< __cplusplus */

#include "mpi_common.h"
#include "mpi_dip_common.h"
#include "mpi_dip_sns.h"
#include "mpi_sys.h"
#include "mpi_osd.h"
#include "sample_sys.h"
#include "sample_dip.h"
#include "sample_osd.h"
#include "sensor.h"
#include "udp_socket.h"
#include "generic_file.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#ifdef SAMPLE_OSD_ON
static OSD_HANDLE g_handle[SAMPLE_MAX_VIDEO_CHN_NUM][MPI_OSD_MAX_BIND_CHANNEL] = { { 0 } };
static int g_osd_run = 0;
char *image_pointer = NULL;
char *pic_image_pointer = NULL;
ASCII_INDEX osdindex[displayable_character_numbers];
pthread_t threadOSDupdate;
UINT32 index_offset;
UINT32 index_size;
UINT32 data_offset;
UINT32 data_size;
UINT32 image_width;
UINT32 image_height;
UINT32 channel_numbers;
UINT32 pic_image_width;
UINT32 pic_image_height;
UINT32 pic_image_size;

MPI_OSD_CANVAS_ATTR_S p_canvas_attr_time_ch0 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_time_ch1 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_time_ch2 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_logo_ch0 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_logo_ch1 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_logo_ch2 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_number_ch0 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_number_ch1 = { 0 };
MPI_OSD_CANVAS_ATTR_S p_canvas_attr_number_ch2 = { 0 };
#endif

/**
 * @brief init OSD handle.
 *
 * @The sample function is used to init OSD handle.
 */
void SAMPLE_initOsdhandle(void)
{
#ifdef SAMPLE_OSD_ON
	/*initial handle to invalid value*/
	memset(g_handle, -1, sizeof(g_handle));
#endif
}

/**
 * @brief Stop OSD.
 * @return The execution result.
 *
 * @The sample function is used to stop OSD.
 */
INT32 SAMPLE_stopOsd(MPI_CHN chn_idx)
{
#ifdef SAMPLE_OSD_ON
	MPI_OSD_BIND_ATTR_S osd_bind = { { 0 } };
	INT32 ret = 0;
	INT32 i = 0;
	INT32 c_idx = MPI_GET_VIDEO_CHN(chn_idx);
	MPI_ECHN e_chn = MPI_ENC_CHN(chn_idx.chn);

	g_osd_run = 0;
	pthread_join(threadOSDupdate, NULL);

	for (i = 0; i < MPI_OSD_MAX_BIND_CHANNEL; i++) {
		if (g_handle[c_idx][i] >= 0) {
			/* Unbind OSD from a video channel */
			osd_bind.idx = e_chn;

			ret = MPI_unbindOsdFromChn(g_handle[c_idx][i], &osd_bind);
			if (ret != MPI_SUCCESS) {
				printf("Unbind OSD %d from channel %d failed.\n", g_handle[c_idx][i],
				       MPI_GET_VIDEO_CHN(chn_idx));
				//				return MPI_FAILURE;
			}
		}
	}

	for (i = 0; i < MPI_OSD_MAX_BIND_CHANNEL; i++) {
		/* Destroy OSD region */
		if (g_handle[c_idx][i] >= 0) {
			ret = MPI_destroyOsdRgn(g_handle[c_idx][i]);
			if (ret != MPI_SUCCESS) {
				printf("Destroy OSD failed.\n");
				g_handle[c_idx][i] = -1;
				//				return MPI_FAILURE;
			}
			g_handle[c_idx][i] = -1;
		}
	}
#endif
	return MPI_SUCCESS;
}

void SAMPLE_free_memory(void)
{
#ifdef SAMPLE_OSD_ON
	free(image_pointer);
	free(pic_image_pointer);
#endif
}

/**
 * @brief Get ayuv file information.
 *
 * @The sample function is used to getting information from ayuv file.
 */
void SAMPLE_getAYUVfileinfo(void)
{
#ifdef SAMPLE_OSD_ON
	FILE *fp;
	FILE *fp_pic;

	fp = fopen("/system/mpp/font/compact_chinese_noalpha.ayuv", "rb");

	fread(&index_offset, sizeof(UINT32), 1, fp);

	fseek(fp, 4, SEEK_SET);
	fread(&index_size, sizeof(UINT32), 1, fp);

	fseek(fp, 8, SEEK_SET);
	fread(&data_offset, sizeof(UINT32), 1, fp);

	fseek(fp, 12, SEEK_SET);
	fread(&data_size, sizeof(UINT32), 1, fp);

	fseek(fp, index_offset, SEEK_SET);
	fread(osdindex, index_size, 1, fp);

	image_pointer = malloc(data_size);

	fseek(fp, data_offset, SEEK_SET);
	fread(image_pointer, data_size, 1, fp);

	fp_pic = fopen("/system/mpp/font/LOGO_Augentix_v2.imgayuv", "rb");

	fread(&pic_image_width, sizeof(UINT32), 1, fp_pic);

	fseek(fp_pic, 4, SEEK_SET);
	fread(&pic_image_height, sizeof(UINT32), 1, fp_pic);

	fseek(fp_pic, 8, SEEK_SET);
	fread(&pic_image_size, sizeof(UINT32), 1, fp_pic);

	pic_image_pointer = malloc(pic_image_size);

	fseek(fp_pic, 12, SEEK_SET);
	fread(pic_image_pointer, pic_image_size, 1, fp_pic);

	fclose(fp);
	fclose(fp_pic);

#endif
}
#ifdef SAMPLE_OSD_ON
/**
 * @brief Update OSD.
 *
 * @The sample function is used to update OSD every 1 second.
 */
static int SAMPLE_update(void)
{
	int i = 0;
	int j = 0;
	int string_lens = 0;
	unsigned char input_ascii = 0;
	UINT32 real_addr = 0;
	INT32 ret = 0;
	char timestring[128];
	int width_acc = 0;
	int week[7][3] = { { 95, 96, 103 }, { 95, 96, 97 },  { 95, 96, 98 }, { 95, 96, 99 },
		           { 95, 96, 100 }, { 95, 96, 101 }, { 95, 96, 102 } };
	int k = 0;

	long utc = time(NULL);
	struct tm gmt_tm;

	while (g_osd_run) {
		utc = time(NULL);
		localtime_r(&utc, &gmt_tm);
		sprintf(timestring, " %4u-%02u-%02u  %02u:%02u:%02u ", gmt_tm.tm_year + 1900, gmt_tm.tm_mon + 1,
		        gmt_tm.tm_mday, gmt_tm.tm_hour, gmt_tm.tm_min, gmt_tm.tm_sec);
		string_lens = strlen(timestring);

		for (i = 0; i < 12; i++) {
			input_ascii = timestring[i];
			input_ascii = input_ascii - 32;
			real_addr = (UINT32)image_pointer + osdindex[input_ascii].image_offset;

			for (j = 0; j < (osdindex[input_ascii].image_height); j++) {
				memcpy((char *)((p_canvas_attr_time_ch0.canvas_addr) + (j * TIME_OSD_SIZE_WIDTH * 2) +
				                (width_acc * 2)),
				       (char *)real_addr, (osdindex[input_ascii].image_width * 2));
				real_addr = (real_addr + (osdindex[input_ascii].image_width * 2));
			}
			width_acc = width_acc + osdindex[input_ascii].image_width;
		}

		for (i = 0; i < 3; i++) {
			input_ascii = week[gmt_tm.tm_wday][k];
			real_addr = (UINT32)image_pointer + osdindex[input_ascii].image_offset;

			for (j = 0; j < (osdindex[input_ascii].image_height); j++) {
				memcpy((char *)((p_canvas_attr_time_ch0.canvas_addr) + (j * TIME_OSD_SIZE_WIDTH * 2) +
				                (width_acc * 2)),
				       (char *)real_addr, (osdindex[input_ascii].image_width * 2));
				real_addr = (real_addr + (osdindex[input_ascii].image_width * 2));
			}
			width_acc = width_acc + osdindex[input_ascii].image_width;
			k++;
		}

		for (i = 12; i < string_lens; i++) {
			input_ascii = timestring[i];
			input_ascii = input_ascii - 32;
			real_addr = (UINT32)image_pointer + osdindex[input_ascii].image_offset;

			for (j = 0; j < (osdindex[input_ascii].image_height); j++) {
				memcpy((char *)((p_canvas_attr_time_ch0.canvas_addr) + (j * TIME_OSD_SIZE_WIDTH * 2) +
				                (width_acc * 2)),
				       (char *)real_addr, (osdindex[input_ascii].image_width * 2));
				real_addr = (real_addr + (osdindex[input_ascii].image_width * 2));
			}
			width_acc = width_acc + osdindex[input_ascii].image_width;
		}

		width_acc = 0;
		k = 0;

		if (channel_numbers > 1) {
			memcpy((char *)(p_canvas_attr_time_ch1.canvas_addr),
			       (char *)(p_canvas_attr_time_ch0.canvas_addr),
			       TIME_OSD_SIZE_WIDTH * TIME_OSD_SIZE_HEIGHT * 2);
		}

		if (channel_numbers == 3) {
			memcpy((char *)(p_canvas_attr_time_ch2.canvas_addr),
			       (char *)(p_canvas_attr_time_ch0.canvas_addr),
			       TIME_OSD_SIZE_WIDTH * TIME_OSD_SIZE_HEIGHT * 2);
		}

		ret = MPI_updateOsdCanvas(g_handle[0][2]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[0][2]);
			return MPI_FAILURE;
		}

		if (channel_numbers > 1) {
			ret = MPI_updateOsdCanvas(g_handle[1][2]);
			if (ret != MPI_SUCCESS) {
				printf("OSD %d to update canvas failed.\n", g_handle[1][2]);
				return MPI_FAILURE;
			}
		}

		if (channel_numbers == 3) {
			ret = MPI_updateOsdCanvas(g_handle[2][2]);
			if (ret != MPI_SUCCESS) {
				printf("OSD %d to update canvas failed.\n", g_handle[2][2]);
				return MPI_FAILURE;
			}
		}

		int cnt = 4;
		while (cnt) {
			usleep(200000);
			if (g_osd_run == 0) {
				break;
			}
			--cnt;
		}
	}

	return 0;
}
#endif
/**
 * @brief Create OSD region.
 * @return The execution result.
 *
 * @The sample function is used to create OSD region.
 */
INT32 SAMPLE_createOsdRegion(MPI_CHN chn_idx, INT32 output_num, UINT16 width, UINT16 height)
{
#ifdef SAMPLE_OSD_ON
	INT32 ret = 0;
	MPI_ECHN e_chn = MPI_ENC_CHN(chn_idx.chn);
	MPI_OSD_RGN_ATTR_S osd_attr = { 0 };
	MPI_OSD_BIND_ATTR_S osd_bind = { { 0 } };

	int i = 0;
	int j = 0;
	UINT32 real_addr = 0;
	char *input_string01 = "Camera 01";
	char *input_string02 = "Camera 02";
	char *input_string03 = "Camera 03";
	int string_lens01 = 0;
	int string_lens02 = 0;
	int string_lens03 = 0;
	int width_acc = 0;
	int time_x;
	int time_y;
	int number_x;
	int number_y;

	unsigned char input_ascii = 0;
	channel_numbers = output_num;
	string_lens01 = strlen(input_string01);
	string_lens02 = strlen(input_string02);
	string_lens03 = strlen(input_string03);

	time_x = width - TIME_OSD_SIZE_WIDTH;
	time_x = (time_x / 16) * 16;
	time_y = height - TIME_OSD_SIZE_HEIGHT;
	time_y = (time_y / 16) * 16;

	number_x = width - NUMBER_OSD_SIZE_WIDTH;
	number_x = (number_x / 16) * 16;
	number_y = height - NUMBER_OSD_SIZE_HEIGHT;
	number_y = (number_y / 16) * 16;

	int c_idx = MPI_GET_VIDEO_CHN(chn_idx);

	if (c_idx == 0) {
		osd_attr.show = 0;
		osd_attr.qp_enable = FALSE;
		osd_attr.color_format = MPI_OSD_COLOR_FORMAT_AYUV_3544;
		osd_attr.osd_type = MPI_OSD_OVERLAY_BITMAP;
		osd_attr.size.width = LOGO_OSD_SIZE_WIDTH;
		osd_attr.size.height = LOGO_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][0], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][0], &p_canvas_attr_logo_ch0);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		for (j = 0; j < pic_image_height; j++) {
			memcpy(((char *)p_canvas_attr_logo_ch0.canvas_addr + (j * LOGO_OSD_SIZE_WIDTH * 2)),
			       ((char *)pic_image_pointer + (j * pic_image_width * 2)), pic_image_width * 2);
		}

		ret = MPI_updateOsdCanvas(g_handle[c_idx][0]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[c_idx][0]);
			return MPI_FAILURE;
		}

		osd_bind.point.x = 16;
		osd_bind.point.y = 16;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][0], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][0], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

		osd_attr.size.width = NUMBER_OSD_SIZE_WIDTH;
		osd_attr.size.height = NUMBER_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][1], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][1], &p_canvas_attr_number_ch0);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		for (i = 0; i < string_lens01; i++) {
			input_ascii = input_string01[i];
			input_ascii = input_ascii - 32;
			real_addr = (UINT32)image_pointer + osdindex[input_ascii].image_offset;

			for (j = 0; j < (osdindex[input_ascii].image_height); j++) {
				memcpy((char *)((p_canvas_attr_number_ch0.canvas_addr) +
				                (j * NUMBER_OSD_SIZE_WIDTH * 2) + (width_acc * 2)),
				       (char *)real_addr, (osdindex[input_ascii].image_width * 2));
				real_addr = (real_addr + (osdindex[input_ascii].image_width * 2));
			}
			width_acc = width_acc + osdindex[input_ascii].image_width;
		}

		width_acc = 0;

		ret = MPI_updateOsdCanvas(g_handle[c_idx][1]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[c_idx][1]);
			return MPI_FAILURE;
		}

		osd_bind.point.x = number_x;
		osd_bind.point.y = 16;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][1], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][1], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

		osd_attr.size.width = TIME_OSD_SIZE_WIDTH;
		osd_attr.size.height = TIME_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][2], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][2], &p_canvas_attr_time_ch0);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		osd_bind.point.x = time_x;
		osd_bind.point.y = time_y;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][2], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][2], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}
	}

	if (c_idx == 1) {
		osd_attr.show = 0;
		osd_attr.qp_enable = FALSE;
		osd_attr.color_format = MPI_OSD_COLOR_FORMAT_AYUV_3544;
		osd_attr.osd_type = MPI_OSD_OVERLAY_BITMAP;
		osd_attr.size.width = LOGO_OSD_SIZE_WIDTH;
		osd_attr.size.height = LOGO_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][0], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][0], &p_canvas_attr_logo_ch1);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		for (j = 0; j < pic_image_height; j++) {
			memcpy(((char *)p_canvas_attr_logo_ch1.canvas_addr + (j * LOGO_OSD_SIZE_WIDTH * 2)),
			       ((char *)pic_image_pointer + (j * pic_image_width * 2)), pic_image_width * 2);
		}

		ret = MPI_updateOsdCanvas(g_handle[c_idx][0]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[c_idx][0]);
			return MPI_FAILURE;
		}

		osd_bind.point.x = 16;
		osd_bind.point.y = 16;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][0], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][0], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

		osd_attr.size.width = NUMBER_OSD_SIZE_WIDTH;
		osd_attr.size.height = NUMBER_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][1], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][1], &p_canvas_attr_number_ch1);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		for (i = 0; i < string_lens02; i++) {
			input_ascii = input_string02[i];
			input_ascii = input_ascii - 32;
			real_addr = (UINT32)image_pointer + osdindex[input_ascii].image_offset;

			for (j = 0; j < (osdindex[input_ascii].image_height); j++) {
				memcpy((char *)((p_canvas_attr_number_ch1.canvas_addr) +
				                (j * NUMBER_OSD_SIZE_WIDTH * 2) + (width_acc * 2)),
				       (char *)real_addr, (osdindex[input_ascii].image_width * 2));
				real_addr = (real_addr + (osdindex[input_ascii].image_width * 2));
			}
			width_acc = width_acc + osdindex[input_ascii].image_width;
		}

		width_acc = 0;

		ret = MPI_updateOsdCanvas(g_handle[c_idx][1]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[c_idx][1]);
			return MPI_FAILURE;
		}

		osd_bind.point.x = number_x;
		osd_bind.point.y = 16;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][1], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][1], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

		osd_attr.size.width = TIME_OSD_SIZE_WIDTH;
		osd_attr.size.height = TIME_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][2], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][2], &p_canvas_attr_time_ch1);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		osd_bind.point.x = time_x;
		osd_bind.point.y = time_y;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][2], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][2], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}
	}

	if (c_idx == 2) {
		osd_attr.show = 0;
		osd_attr.qp_enable = FALSE;
		osd_attr.color_format = MPI_OSD_COLOR_FORMAT_AYUV_3544;
		osd_attr.osd_type = MPI_OSD_OVERLAY_BITMAP;
		osd_attr.size.width = LOGO_OSD_SIZE_WIDTH;
		osd_attr.size.height = LOGO_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][0], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][0], &p_canvas_attr_logo_ch2);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		for (j = 0; j < pic_image_height; j++) {
			memcpy(((char *)p_canvas_attr_logo_ch2.canvas_addr + (j * LOGO_OSD_SIZE_WIDTH * 2)),
			       ((char *)pic_image_pointer + (j * pic_image_width * 2)), pic_image_width * 2);
		}

		ret = MPI_updateOsdCanvas(g_handle[c_idx][0]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[c_idx][0]);
			return MPI_FAILURE;
		}

		osd_bind.point.x = 16;
		osd_bind.point.y = 16;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][0], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][0], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

		osd_attr.size.width = NUMBER_OSD_SIZE_WIDTH;
		osd_attr.size.height = NUMBER_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][1], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][1], &p_canvas_attr_number_ch2);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		for (i = 0; i < string_lens03; i++) {
			input_ascii = input_string03[i];
			input_ascii = input_ascii - 32;
			real_addr = (UINT32)image_pointer + osdindex[input_ascii].image_offset;

			for (j = 0; j < (osdindex[input_ascii].image_height); j++) {
				memcpy((char *)((p_canvas_attr_number_ch2.canvas_addr) +
				                (j * NUMBER_OSD_SIZE_WIDTH * 2) + (width_acc * 2)),
				       (char *)real_addr, (osdindex[input_ascii].image_width * 2));
				real_addr = (real_addr + (osdindex[input_ascii].image_width * 2));
			}
			width_acc = width_acc + osdindex[input_ascii].image_width;
		}

		width_acc = 0;

		ret = MPI_updateOsdCanvas(g_handle[c_idx][1]);
		if (ret != MPI_SUCCESS) {
			printf("OSD %d to update canvas failed.\n", g_handle[c_idx][1]);
			return MPI_FAILURE;
		}

		osd_bind.point.x = number_x;
		osd_bind.point.y = 16;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][1], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][1], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

		osd_attr.size.width = TIME_OSD_SIZE_WIDTH;
		osd_attr.size.height = TIME_OSD_SIZE_HEIGHT;

		ret = MPI_createOsdRgn(&g_handle[c_idx][2], &osd_attr);
		if (ret != MPI_SUCCESS) {
			printf("MPI_OSD_CreateRgn failed.\n");
			return MPI_FAILURE;
		}

		ret = MPI_getOsdCanvas(g_handle[c_idx][2], &p_canvas_attr_time_ch2);
		if (ret != MPI_SUCCESS) {
			printf("MPI_getOsdCanvas failed.\n");
			return MPI_FAILURE;
		}

		osd_bind.point.x = time_x;
		osd_bind.point.y = time_y;
		osd_bind.idx = e_chn;

		ret = MPI_bindOsdToChn(g_handle[c_idx][2], &osd_bind);
		if (ret != MPI_SUCCESS) {
			printf("Bind OSD %d to channel %d failed.\n", g_handle[c_idx][2], MPI_GET_VIDEO_CHN(chn_idx));
			return MPI_FAILURE;
		}

	}

	if (c_idx == (output_num - 1)) {
		g_osd_run = 1;

		ret = pthread_create(&threadOSDupdate, NULL, (void *)SAMPLE_update, NULL);
		if (ret) {
			printf("Failed to create OSD thread !\n");
			return MPI_FAILURE;
		}
	}

#endif

	return MPI_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /**< __cplusplus */
